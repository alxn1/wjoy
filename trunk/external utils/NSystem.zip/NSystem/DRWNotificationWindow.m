//
//  DRWNotificationWindow.m
//  NSystem
//
//  Created by alxn1 on 19.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWNotificationWindow.h"

@implementation DRWNotificationWindow

+ (NSRect)bestRectForNotification:(DRWUserNotification*)aNotification
{
    return [DRWNotificationWindowView
                        bestViewRectForTitle:[aNotification title]
                                        text:[aNotification text]];
}

+ (DRWNotificationWindow*)newWindowWithNotification:(DRWUserNotification*)aNotification frame:(NSRect)frame
{
    return [[[DRWNotificationWindow alloc]
                        initWithNotification:aNotification
                                       frame:frame] autorelease];
}

- (id)initWithNotification:(DRWUserNotification*)aNotification frame:(NSRect)frame
{
    self = [super initWithContentRect:frame
                            styleMask:NSBorderlessWindowMask
                              backing:NSBackingStoreBuffered
                                defer:NO];

    if(self == nil) return nil;

    [self setOpaque:NO];
    [self setOneShot:NO];
    [self setMovable:NO];
    [self setHasShadow:YES];
    [self setLevel:kCGMaximumWindowLevel];
    [self setAcceptsMouseMovedEvents:YES];
    [self setMovableByWindowBackground:NO];
    [self setBackgroundColor:[NSColor clearColor]];
    [self setReleasedWhenClosed:NO];
    [self setExcludedFromWindowsMenu:YES];
    [self setCollectionBehavior:
            NSWindowCollectionBehaviorCanJoinAllSpaces |
            NSWindowCollectionBehaviorTransient |
            NSWindowCollectionBehaviorIgnoresCycle];

    [self setAnimationEnabled:YES];

    NSRect contentViewFrame = frame;
    contentViewFrame.origin = NSZeroPoint;
    DRWNotificationWindowView *contentView = [[DRWNotificationWindowView alloc] initWithFrame:contentViewFrame];
    [contentView setIcon:[[NSApplication sharedApplication] applicationIconImage]];
    [contentView setText:[aNotification text]];
    [contentView setTitle:[aNotification title]];
    [contentView setDelegate:self];
    [contentView setTarget:self];
    [contentView setAction:@selector(contentViewClicked:)];
    [self setContentView:contentView];
    [contentView release];

    notification = [aNotification retain];
    isMouseEntered = NO;
    isCloseOnMouseExited = NO;

    return self;
}

- (void)dealloc
{
    [autocloseTimer invalidate];
    [notification release];
    [super dealloc];
}

- (id)target
{
    return target;
}

- (void)setTarget:(id)obj
{
    target = obj;
}

- (SEL)action
{
    return action;
}

- (void)setAction:(SEL)sel
{
    action = sel;
}

- (void)showWithTimeout:(NSTimeInterval)timeout
{
    [self orderFront:self];
    [self startAutocloseTimer:timeout];
}

- (void)close
{
    [autocloseTimer invalidate];
    autocloseTimer = nil;
    [super close];
}

- (DRWUserNotification*)notification
{
    return [[notification retain] autorelease];
}

// MARK: NSWindow overrides

- (BOOL)canBecomeKeyWindow
{
    return NO;
}

- (BOOL)canBecomeMainWindow
{
    return NO;
}

// MARK: private

- (void)startAutocloseTimer:(NSTimeInterval)timeout
{
    if(autocloseTimer == nil) {
        autocloseTimer = [NSTimer scheduledTimerWithTimeInterval:timeout
                                                          target:self
                                                        selector:@selector(autoclose:)
                                                        userInfo:nil
                                                         repeats:NO];

        [[NSRunLoop currentRunLoop] addTimer:autocloseTimer forMode:NSEventTrackingRunLoopMode];
        [[NSRunLoop currentRunLoop] addTimer:autocloseTimer forMode:NSModalPanelRunLoopMode];
    }
}

- (void)autoclose:(id)sender
{
    autocloseTimer = nil;
    if(!isMouseEntered) [self close];
    else isCloseOnMouseExited = YES;
}

- (void)contentViewClicked:(id)sender
{
    if(target != nil && action != nil) {
        [target performSelector:action withObject:self];
    }
}

// MARK: DRWNotificationWindowViewDelegate

- (void)notificationWindowViewMouseEntered:(DRWNotificationWindowView*)view
{
    isMouseEntered = YES;
}

- (void)notificationWindowViewMouseExited:(DRWNotificationWindowView*)view
{
    isMouseEntered = NO;
    if(isCloseOnMouseExited) [self close];
}

@end

//
//  DRWAnimatedWindow.m
//  Scanner
//
//  Created by alxn1 on 26.10.11.
//  Copyright 2011 Dr. Web. All rights reserved.
//

#import "DRWAnimatedWindow.h"

@implementation DRWAnimatedWindow

#import "DRWAnimatedWindowBase.m"

@end

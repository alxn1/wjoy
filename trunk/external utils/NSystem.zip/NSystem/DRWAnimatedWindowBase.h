//
//  DRWAnimatedWindowBase.h
//  NewGUITestBench
//
//  Created by Alexander Serkov on 27.10.11.
//  Copyright 2011 Dr. Web. All rights reserved.
//

{
@private
    NSViewAnimation *currentAnimation;
    BOOL isAnimationEnabled;
}

// MARK: NSWindow overrides

- (id)initWithContentRect:(NSRect)contentRect
                styleMask:(unsigned)aStyle
                  backing:(NSBackingStoreType)bufferingType
                    defer:(BOOL)flag;

- (id)initWithContentRect:(NSRect)contentRect
                styleMask:(unsigned)aStyle
                  backing:(NSBackingStoreType)bufferingType
                    defer:(BOOL)flag
                   screen:(NSScreen *)screen;

- (id)initWithCoder:(NSCoder*)decoder;
- (void)dealloc;

- (void)makeKeyAndOrderFromWithoutAnimation:(id)sender;
- (void)makeKeyAndOrderFront:(id)sender;
- (void)orderFront:(id)sender;
- (void)orderOut:(id)sender;
- (void)close;

// MARK: public

- (BOOL)isAnimationEnabled;
- (void)setAnimationEnabled:(BOOL)enabled;

// MARK: private

- (void)fadeIn;
- (void)fadeOut;

// NSViewAnimation delegate

- (void)animationDidEnd:(NSAnimation*)animation;

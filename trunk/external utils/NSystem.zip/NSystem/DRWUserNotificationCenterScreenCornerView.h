//
//  DRWUserNotificationCenterScreenCornerView.h
//  NSystem
//
//  Created by alxn1 on 20.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWUserNotificationCenter.h"

@interface DRWUserNotificationCenterScreenCornerView : NSView {
@private
    DRWUserNotificationCenterScreenCorner screenCorner;
    int underMouseScreenCorner;
    int draggedMouseScreenCorner;
    int clickedMouseScreenCorner;
    BOOL isEnabled;

    id target;
    SEL action;

    NSTrackingRectTag trackingRectTags[4];
}

// MARK: public

+ (NSSize)bestSize;

- (id)initWithFrame:(NSRect)frame;
- (id)initWithCoder:(NSCoder*)decoder;
- (void)dealloc;

- (void)drawRect:(NSRect)rect;

- (void)setFrame:(NSRect)frameRect;
- (void)viewDidEndLiveResize;

- (void)mouseDown:(NSEvent*)event;
- (void)mouseDragged:(NSEvent*)event;
- (void)mouseUp:(NSEvent*)event;

- (void)mouseEntered:(NSEvent*)event;
- (void)mouseExited:(NSEvent*)event;

- (BOOL)isEnabled;
- (void)setEnabled:(BOOL)enabled;

- (DRWUserNotificationCenterScreenCorner)screenCorner;
- (void)setScreenCorner:(DRWUserNotificationCenterScreenCorner)corner;

- (id)target;
- (void)setTarget:(id)obj;

- (SEL)action;
- (void)setAction:(SEL)sel;

// MARK: private

- (NSBezierPath*)pathForCornerPoint;
- (NSBezierPath*)pathForTriangle:(DRWUserNotificationCenterScreenCorner)corner;

- (void)drawScreenCorner:(DRWUserNotificationCenterScreenCorner)corner;

- (void)updateTrackingRects;
- (void)removeTrackingRects;
- (int)screenCornerFromEvent:(NSEvent*)event;

@end

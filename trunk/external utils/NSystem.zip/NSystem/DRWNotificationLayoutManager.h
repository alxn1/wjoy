//
//  DRWNotificationLayoutManager.h
//  NSystem
//
//  Created by alxn1 on 20.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWUserNotificationCenter.h"
#import "DRWNotificationWindow.h"

@interface DRWNotificationLayoutManager : NSObject {
}

// MARK: public

+ (DRWNotificationLayoutManager*)managerWithScreenCorner:(DRWUserNotificationCenterScreenCorner)screenCorner;

- (DRWUserNotificationCenterScreenCorner)screenCorner;

- (BOOL)hasSpaceForNotification:(DRWUserNotification*)notification
            activeNotifications:(NSArray*)activeNotifications
                           rect:(NSRect*)resultRect
                          index:(NSUInteger*)index;

// MARK: protected

- (NSRect)screenRect;

- (BOOL)hasSpaceBeforeFirst:(NSRect)bestRect
        activeNotifications:(NSArray*)activeNotifications
                       rect:(NSRect*)resultRect;

- (BOOL)hasSpaceBetween:(NSRect)bestRect
              firstRect:(NSRect)firstRect
             secondRect:(NSRect)secondRect
    activeNotifications:(NSArray*)activeNotifications
                   rect:(NSRect*)resultRect;

- (BOOL)hasSpaceAfterLast:(NSRect)bestRect
      activeNotifications:(NSArray*)activeNotifications
                     rect:(NSRect*)resultRect;

@end

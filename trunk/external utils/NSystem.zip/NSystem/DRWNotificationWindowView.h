//
//  DRWNotificationWindowView.h
//  NSystem
//
//  Created by alxn1 on 19.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class DRWNotificationWindowView;

@protocol DRWNotificationWindowViewDelegate

- (void)notificationWindowViewMouseEntered:(DRWNotificationWindowView*)view;
- (void)notificationWindowViewMouseExited:(DRWNotificationWindowView*)view;

@end

@interface DRWNotificationWindowView : NSView {
@private
    NSImage *icon;
    NSString *title;
    NSString *text;

    NSTrackingRectTag trackingRectTag;

    BOOL isHowered;
    BOOL isCloseButtonDragged;
    BOOL isCloseButtonPressed;
    BOOL isAlreadyClicked;

    id target;
    SEL action;

    id<DRWNotificationWindowViewDelegate> delegate;
}

// MARK: public

+ (NSRect)bestViewRectForTitle:(NSString*)title text:(NSString*)text;

- (id)initWithFrame:(NSRect)rect;
- (id)initWithCoder:(NSCoder*)decoder;
- (void)dealloc;

- (NSImage*)icon;
- (void)setIcon:(NSImage*)img;

- (NSString*)title;
- (void)setTitle:(NSString*)str;

- (NSString*)text;
- (void)setText:(NSString*)str;

- (id)target;
- (void)setTarget:(id)obj;

- (SEL)action;
- (void)setAction:(SEL)sel;

- (id<DRWNotificationWindowViewDelegate>)delegate;
- (void)setDelegate:(id<DRWNotificationWindowViewDelegate>)obj;

- (void)viewDidHide;
- (void)viewDidUnhide;

- (BOOL)acceptsFirstMouse:(NSEvent*)event;
- (void)mouseDown:(NSEvent*)event;
- (void)mouseDragged:(NSEvent*)event;
- (void)mouseUp:(NSEvent*)event;
- (void)mouseEntered:(NSEvent*)event;
- (void)mouseExited:(NSEvent*)event;

- (void)drawRect:(NSRect)rect;

// MARK: private

- (BOOL)isHowered;
- (void)setHowered:(BOOL)hovered;

- (BOOL)isCloseButtonPressed;
- (void)setCloseButtonPressed:(BOOL)pressed;

- (BOOL)isMouseInside;
- (void)removeTrackingRect;
- (void)updateTrackingRect;

- (NSRect)closeButtonRect:(NSRect)rect;
- (NSRect)iconRect:(NSRect)rect;
- (NSRect)titleRect:(NSRect)rect attributes:(NSDictionary*)attributes;
- (NSSize)maxTextSize:(NSRect)rect titleHeight:(float)titleHeight;
- (NSRect)textRect:(NSRect)rect titleHeight:(float)titleHeight attributes:(NSDictionary*)attributes;

- (void)drawCloseButton:(NSRect)rect;

+ (NSDictionary*)titleTextAttributes;
+ (NSDictionary*)textAttributes;

+ (NSSize)titleSize:(NSString*)title;
+ (NSSize)textSize:(NSString*)text;

@end

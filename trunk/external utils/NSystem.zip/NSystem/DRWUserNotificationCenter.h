//
//  DRWUserNotificationCenter.h
//  NSystem
//
//  Created by alxn1 on 18.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWUserNotification.h"

typedef enum {
    DRWUserNotificationCenterScreenCornerRightTop,
    DRWUserNotificationCenterScreenCornerRightBottom,
    DRWUserNotificationCenterScreenCornerLeftBottom,
    DRWUserNotificationCenterScreenCornerLeftTop
} DRWUserNotificationCenterScreenCorner;

#define DRWUserNotificationClickedNotification      @"DRWUserNotificationClickedNotification"
            // object => DRWUserNotification

#define DRWUserNotificationCenterTimeoutKey         @"DRWUserNotificationCenterTimeoutKey"
#define DRWUserNotificationCenterScreenCornerKey    @"DRWUserNotificationCenterScreenCornerKey"

@class DRWUserNotificationCenter;

@protocol DRWUserNotificationCenterDelegate

- (BOOL)userNotificationCenter:(DRWUserNotificationCenter*)center
     shouldDeliverNotification:(DRWUserNotification*)notification;

- (void)userNotificationCenter:(DRWUserNotificationCenter*)center
           notificationClicked:(DRWUserNotification*)notification;

@end

@interface DRWUserNotificationCenter : NSObject {
}

// MARK: public

+ (NSArray*)all;
+ (NSArray*)available;
+ (DRWUserNotificationCenter*)best;
+ (DRWUserNotificationCenter*)withName:(NSString*)name;

+ (BOOL)isSoundEnabled;
+ (void)setSoundEnabled:(BOOL)enabled;

+ (NSString*)soundName;
+ (void)setSoundName:(NSString*)name;

+ (void)deliver:(DRWUserNotification*)notification;

+ (id<DRWUserNotificationCenterDelegate>)delegate;
+ (void)setDelegate:(id<DRWUserNotificationCenterDelegate>)obj;

// MARK: notification system interface

- (BOOL)isAvailable;

- (NSString*)name;
- (NSUInteger)merit;

- (void)deliver:(DRWUserNotification*)notification;

- (NSDictionary*)customSettings;
- (void)setCustomSettings:(NSDictionary*)preferences;

// MARK: protected, only for notification system subclasses

+ (void)registerImpl:(DRWUserNotificationCenter*)impl;

+ (BOOL)shouldDeliverNotification:(DRWUserNotification*)notification
                           center:(DRWUserNotificationCenter*)center;

+ (void)notificationClicked:(DRWUserNotification*)notification
                     center:(DRWUserNotificationCenter*)center;

// MARK: private

+ (void)postClickedNotification:(DRWUserNotification*)notification;

@end

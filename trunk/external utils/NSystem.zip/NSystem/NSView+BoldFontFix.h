//
//  NSView+BoldFontFix.h
//  Scanner
//
//  Created by alxn1 on 09.11.11.
//  Copyright 2011 Dr. Web. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSView (BoldFontFix)

// MARK: protected

+ (void)beginDraw;
+ (void)endDraw;

+ (void)initClassFontFix:(SEL)newDrawRectSelector;

@end

//
//  DRWNotificationSystem.m
//  NSystem
//
//  Created by alxn1 on 19.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWNotificationSystem.h"
#import "DRWNotificationWindow.h"
#import "DRWNotificationLayoutManager.h"

@implementation DRWNotificationSystem

// MARK: public

+ (DRWNotificationSystem*)sharedInstance
{
    static DRWNotificationSystem *result = nil;
    if(result == nil) result = [[DRWNotificationSystem alloc] init];
    return result;
}

- (NSTimeInterval)notificationTimeout
{
    return notificationTimeout;
}

- (void)setNotificationTimeout:(NSTimeInterval)timeout
{
    notificationTimeout = timeout;
}

- (DRWUserNotificationCenterScreenCorner)screenCorner
{
    return [layoutManager screenCorner];
}

- (void)setScreenCorner:(DRWUserNotificationCenterScreenCorner)corner
{
    if([self screenCorner] == corner) return;

    [layoutManager release];
    layoutManager = [[DRWNotificationLayoutManager managerWithScreenCorner:corner] retain];

    NSUInteger countOpenedWindows = [activeNotifications count];
    for(NSUInteger i = 0; i < countOpenedWindows; i++) {
        DRWNotificationWindow *w = [activeNotifications objectAtIndex:i];
        [w setReleasedWhenClosed:YES];
        [w setDelegate:nil];
        [w retain];
        [w close];
    }
    [activeNotifications removeAllObjects];
}

- (void)deliver:(DRWUserNotification*)notification
{
    NSRect      rect;
    NSUInteger  index;

    if([self hasSpaceForNotification:notification rect:&rect index:&index]) {
        [self showNotification:notification rect:rect index:index];
    }
    else [notificationQueue addObject:notification];
}

- (id<DRWNotificationSystemDelegate>)delegate
{
    return delegate;
}

- (void)setDelegate:(id<DRWNotificationSystemDelegate>)obj
{
    delegate = obj;
}

// MARK: private

- (id)init
{
    self = [super init];
    if(self == nil)
        return nil;

    layoutManager       = [[DRWNotificationLayoutManager managerWithScreenCorner:
                                        DRWUserNotificationCenterScreenCornerRightTop]
                                retain];

    notificationQueue   = [[NSMutableArray alloc] init];
    activeNotifications = [[NSMutableArray alloc] init];
    notificationTimeout = 5.0;

    [[NSNotificationCenter defaultCenter]
        addObserver:self
           selector:@selector(applicationDidChangeScreenParametersNotification:)
               name:NSApplicationDidChangeScreenParametersNotification
             object:nil];

    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];

    [notificationQueue release];
    [activeNotifications release];
    [layoutManager release];
    [super dealloc];
}

- (BOOL)hasSpaceForNotification:(DRWUserNotification*)notification rect:(NSRect*)resultRect index:(NSUInteger*)index
{
    return [layoutManager hasSpaceForNotification:notification
                              activeNotifications:activeNotifications
                                             rect:resultRect
                                            index:index];
}

- (void)showNotification:(DRWUserNotification*)notification rect:(NSRect)rect index:(NSUInteger)index
{
    DRWNotificationWindow *window = [DRWNotificationWindow newWindowWithNotification:notification frame:rect];

    [window setTarget:self];
    [window setAction:@selector(notificationClicked:)];
    [window setDelegate:self];
    [window showWithTimeout:notificationTimeout];

    [activeNotifications insertObject:window atIndex:index];
}

- (void)notificationClicked:(id)sender
{
    [delegate notificationSystem:self
             notificationClicked:[(DRWNotificationWindow*)sender notification]];
}

// MARK: NSWindow delegate

- (void)showNextNotificationFromQueue
{
    if([notificationQueue count] != 0) {
        NSRect               rect;
        NSUInteger           index;
        DRWUserNotification *n = [notificationQueue objectAtIndex:0];

        if([self hasSpaceForNotification:n rect:&rect index:&index]) {
            [self showNotification:n rect:rect index:index];
            [notificationQueue removeObjectAtIndex:0];
        }
    }
}

- (void)windowWillClose:(NSNotification*)notification
{
    [activeNotifications removeObject:[notification object]];
    [self showNextNotificationFromQueue];
}

// MARK: NSApplication notifications

- (void)applicationDidChangeScreenParametersNotification:(NSNotification*)notification
{
    NSUInteger countOpenedWindows = [activeNotifications count];
    for(NSUInteger i = 0; i < countOpenedWindows; i++) {
        DRWNotificationWindow *w = [activeNotifications objectAtIndex:i];
        [w setAnimationEnabled:NO];
        [w setDelegate:nil];
        [w close];
    }
    [activeNotifications removeAllObjects];
    [self showNextNotificationFromQueue];
}

@end

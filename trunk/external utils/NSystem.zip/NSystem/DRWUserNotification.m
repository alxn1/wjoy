//
//  DRWUserNotification.m
//  NSystem
//
//  Created by alxn1 on 18.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWUserNotification.h"

@implementation DRWUserNotification

+ (DRWUserNotification*)userNotificationWithTitle:(NSString*)aTitle text:(NSString*)aText
{
    return [[[DRWUserNotification alloc] initWithTitle:aTitle text:aText userInfo:nil tag:0] autorelease];
}

+ (DRWUserNotification*)userNotificationWithTitle:(NSString*)aTitle text:(NSString*)aText tag:(NSInteger)aTag
{
    return [[[DRWUserNotification alloc] initWithTitle:aTitle text:aText userInfo:nil tag:aTag] autorelease];
}

+ (DRWUserNotification*)userNotificationWithTitle:(NSString*)aTitle text:(NSString*)aText userInfo:(NSDictionary*)aUserInfo
{
    return [[[DRWUserNotification alloc] initWithTitle:aTitle text:aText userInfo:aUserInfo tag:0] autorelease];
}

+ (DRWUserNotification*)userNotificationWithTitle:(NSString*)aTitle text:(NSString*)aText userInfo:(NSDictionary*)aUserInfo tag:(NSInteger)aTag
{
    return [[[DRWUserNotification alloc] initWithTitle:aTitle text:aText userInfo:aUserInfo tag:aTag] autorelease];
}

- (id)initWithTitle:(NSString*)aTitle text:(NSString*)aText userInfo:(NSDictionary*)aUserInfo tag:(NSInteger)aTag
{
    self = [super init];
    if(self == nil) return nil;

    title = [aTitle copy];
    text = [aText copy];
    userInfo = [aUserInfo copy];
    tag = aTag;

    [self checkFields];

    return self;
}

- (id)initWithDictionary:(NSDictionary*)dictionary
{
    self = [super init];
    if(self == nil) return nil;

    title = [[dictionary objectForKey:@"title"] retain];
    text = [[dictionary objectForKey:@"text"] retain];
    userInfo = [[dictionary objectForKey:@"userInfo"] retain];
    tag = [[dictionary objectForKey:@"tag"] integerValue];

    [self checkFields];

    return self;
}

- (id)initWithCoder:(NSCoder*)decoder
{
    self = [super init];
    if(self == nil) return nil;

    if([decoder allowsKeyedCoding]) {
        title = [[decoder decodeObjectForKey:@"title"] retain];
        text = [[decoder decodeObjectForKey:@"text"] retain];
        userInfo = [[decoder decodeObjectForKey:@"userInfo"] retain];
        tag = [decoder decodeIntegerForKey:@"tag"];
    }
    else {
        title = [[decoder decodeObject] retain];
        text = [[decoder decodeObject] retain];
        userInfo = [[decoder decodeObject] retain];
        tag = [[decoder decodeObject] integerValue];
    }

    [self checkFields];

    return self;
}

- (void)dealloc
{
    [title release];
    [text release];
    [userInfo release];
    [super dealloc];
}

- (NSString*)title
{
    return [[title retain] autorelease];
}

- (NSString*)text
{
    return [[text retain] autorelease];
}

- (NSDictionary*)userInfo
{
    return [[userInfo retain] autorelease];
}

- (NSInteger)tag
{
    return tag;
}

- (void)encodeWithCoder:(NSCoder*)coder
{
    if([coder allowsKeyedCoding]) {
        [coder encodeObject:title forKey:@"title"];
        [coder encodeObject:text forKey:@"text"];
        [coder encodeObject:userInfo forKey:@"userInfo"];
        [coder encodeInteger:tag forKey:@"tag"];
    }
    else {
        [coder encodeObject:title];
        [coder encodeObject:text];
        [coder encodeObject:userInfo];
        [coder encodeObject:[NSNumber numberWithInteger:tag]];
    }
}

- (NSDictionary*)asDictionary
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];

    if(title != nil) [dict setObject:title forKey:@"title"];
    if(text != nil) [dict setObject:text forKey:@"text"];
    if(userInfo != nil) [dict setObject:userInfo forKey:@"userInfo"];
    [dict setObject:[NSNumber numberWithInteger:tag] forKey:@"tag"];

    return dict;
}

- (NSString*)description
{
    return [[self asDictionary] description];
}

// MARK: private

- (void)checkFields
{
    if(title == nil) title = @"";
    if(text == nil) text = @"";
    if(userInfo == nil) userInfo = [[NSDictionary alloc] init];
}

@end

//
//  NSView+BoldFontFix.m
//  Scanner
//
//  Created by alxn1 on 09.11.11.
//  Copyright 2011 Dr. Web. All rights reserved.
//

#import "NSView+BoldFontFix.h"

#import "NSObject+Swizzle.h"

@implementation NSView (BoldFontFix)

// MARK: protected

+ (void)beginDraw
{
    [NSGraphicsContext saveGraphicsState];
    CGContextSetShouldSmoothFonts([[NSGraphicsContext currentContext] graphicsPort], NO);
}

+ (void)endDraw
{
    [NSGraphicsContext restoreGraphicsState];
}

+ (void)initClassFontFix:(SEL)newDrawRectSelector
{
    [self swizzleMethod:@selector(drawRect:) withMethod:newDrawRectSelector];
}

@end

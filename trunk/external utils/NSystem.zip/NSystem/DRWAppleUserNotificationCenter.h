//
//  DRWAppleUserNotificationCenter.h
//  NSystem
//
//  Created by alxn1 on 18.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWUserNotificationCenter.h"

@interface DRWAppleUserNotificationCenter : DRWUserNotificationCenter {
@private
    Class notificationClass;
    Class notificationCenterClass;
}

// MARK: public

+ (void)load;

- (BOOL)isAvailable;

- (NSString*)name;
- (NSUInteger)merit;

- (void)deliver:(DRWUserNotification*)notification;

// MARK: private

+ (BOOL)isAvailable;

- (id)init;
- (void)dealloc;

- (void)userNotificationCenter:(id)center didActivateNotification:(id)notification;

// MARK: NSApplication notifications

- (void)applicationWillTerminateNotification:(NSNotification*)notification;

@end

//
//  DRWOwnUserNotificationCenter.h
//  NSystem
//
//  Created by alxn1 on 18.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWUserNotificationCenter.h"
#import "DRWNotificationSystem.h"

@interface DRWOwnUserNotificationCenter : DRWUserNotificationCenter<DRWNotificationSystemDelegate> {
}

// MARK: public

+ (void)load;

- (BOOL)isAvailable;

- (NSString*)name;
- (NSUInteger)merit;

- (void)deliver:(DRWUserNotification*)notification;

- (NSDictionary*)customSettings;
- (void)setCustomSettings:(NSDictionary*)preferences;

// MARK: private

- (id)init;

// MARK: DRWNotificationSystemDelegate

- (void)notificationSystem:(DRWNotificationSystem*)system
       notificationClicked:(DRWUserNotification*)notification;

@end

//
//  DRWNotificationSystem.h
//  NSystem
//
//  Created by alxn1 on 19.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWUserNotificationCenter.h"

@class DRWNotificationSystem;
@class DRWNotificationLayoutManager;

@protocol DRWNotificationSystemDelegate

- (void)notificationSystem:(DRWNotificationSystem*)system
       notificationClicked:(DRWUserNotification*)notification;

@end

@interface DRWNotificationSystem : NSObject<NSWindowDelegate> {
@private
    DRWNotificationLayoutManager *layoutManager;
    NSMutableArray *notificationQueue;
    NSMutableArray *activeNotifications;

    NSTimeInterval notificationTimeout;

    id<DRWNotificationSystemDelegate> delegate;
}

// MARK: public

+ (DRWNotificationSystem*)sharedInstance;

- (NSTimeInterval)notificationTimeout;
- (void)setNotificationTimeout:(NSTimeInterval)timeout;

- (DRWUserNotificationCenterScreenCorner)screenCorner;
- (void)setScreenCorner:(DRWUserNotificationCenterScreenCorner)corner;

- (void)deliver:(DRWUserNotification*)notification;

- (id<DRWNotificationSystemDelegate>)delegate;
- (void)setDelegate:(id<DRWNotificationSystemDelegate>)obj;

// MARK: private

- (id)init;
- (void)dealloc;

- (BOOL)hasSpaceForNotification:(DRWUserNotification*)notification
                           rect:(NSRect*)resultRect
                          index:(NSUInteger*)index;

- (void)showNotification:(DRWUserNotification*)notification
                    rect:(NSRect)rect
                   index:(NSUInteger)index;

- (void)showNextNotificationFromQueue;

- (void)notificationClicked:(id)sender;

// MARK: NSWindow delegate

- (void)windowWillClose:(NSNotification*)notification;

// MARK: NSApplication notifications

- (void)applicationDidChangeScreenParametersNotification:(NSNotification*)notification;

@end

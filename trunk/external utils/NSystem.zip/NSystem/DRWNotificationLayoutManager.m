//
//  DRWNotificationLayoutManager.m
//  NSystem
//
//  Created by alxn1 on 20.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWRightTopNotificationLayoutManager.h"
#import "DRWRightBottomNotificationLayoutManager.h"
#import "DRWLeftBottomNotificationLayoutManager.h"
#import "DRWLeftTopNotificationLayoutManager.h"

@implementation DRWNotificationLayoutManager

// MARK: public

+ (DRWNotificationLayoutManager*)managerWithScreenCorner:(DRWUserNotificationCenterScreenCorner)screenCorner
{
    static DRWNotificationLayoutManager *rightTop = nil;
    static DRWNotificationLayoutManager *rightBottom = nil;
    static DRWNotificationLayoutManager *leftBottom = nil;
    static DRWNotificationLayoutManager *leftTop = nil;

    DRWNotificationLayoutManager *result = nil;

    switch(screenCorner) {
        case DRWUserNotificationCenterScreenCornerRightTop: {
            if(rightTop == nil) rightTop = [[DRWRightTopNotificationLayoutManager alloc] init];
            result = rightTop;
            break;
        }

        case DRWUserNotificationCenterScreenCornerRightBottom: {
            if(rightBottom == nil) rightBottom = [[DRWRightBottomNotificationLayoutManager alloc] init];
            result = rightBottom;
            break;
        }

        case DRWUserNotificationCenterScreenCornerLeftBottom: {
            if(leftBottom == nil) leftBottom = [[DRWLeftBottomNotificationLayoutManager alloc] init];
            result = leftBottom;
            break;
        }

        case DRWUserNotificationCenterScreenCornerLeftTop: {
            if(leftTop == nil) leftTop = [[DRWLeftTopNotificationLayoutManager alloc] init];
            result = leftTop;
            break;
        }
    }

    return result;
}

- (DRWUserNotificationCenterScreenCorner)screenCorner
{
    return DRWUserNotificationCenterScreenCornerRightTop;
}

- (BOOL)hasSpaceForNotification:(DRWUserNotification*)notification
            activeNotifications:(NSArray*)activeNotifications
                           rect:(NSRect*)resultRect
                          index:(NSUInteger*)index
{
    NSRect screenRect   = [self screenRect];
    NSRect bestRect     = [DRWNotificationWindow bestRectForNotification:notification];

    if(bestRect.size.height > screenRect.size.height)
        bestRect.size.height = screenRect.size.height;

    if([self hasSpaceBeforeFirst:bestRect
             activeNotifications:activeNotifications
                            rect:resultRect]) {
        if(index != NULL) *index = 0;
        return YES;
    }

    NSUInteger countActive = [activeNotifications count];
    for(NSUInteger i = 0; i < (countActive - 1); i++) {
        if([self hasSpaceBetween:bestRect
                       firstRect:[[activeNotifications objectAtIndex:i] frame]
                      secondRect:[[activeNotifications objectAtIndex:i + 1] frame]
             activeNotifications:activeNotifications
                            rect:resultRect]) {
            if(index != NULL) *index = i + 1;
            return YES;
        }
    }

    if([self hasSpaceAfterLast:bestRect
           activeNotifications:activeNotifications
                          rect:resultRect]) {
        if(index != NULL) *index = countActive;
        return YES;
    }

    return NO;
}

// MARK: protected

- (NSRect)screenRect
{
    return NSInsetRect([[NSScreen mainScreen] visibleFrame], 15.0f, 15.0f);
}

- (BOOL)hasSpaceBeforeFirst:(NSRect)bestRect
        activeNotifications:(NSArray*)activeNotifications
                       rect:(NSRect*)resultRect
{
    return NO;
}

- (BOOL)hasSpaceBetween:(NSRect)bestRect
              firstRect:(NSRect)firstRect
             secondRect:(NSRect)secondRect
    activeNotifications:(NSArray*)activeNotifications
                   rect:(NSRect*)resultRect
{
    return NO;
}

- (BOOL)hasSpaceAfterLast:(NSRect)bestRect
      activeNotifications:(NSArray*)activeNotifications
                     rect:(NSRect*)resultRect
{
    return NO;
}

@end

//
//  MainController.h
//  NSystem
//
//  Created by alxn1 on 18.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class DRWUserNotificationCenterScreenCornerView;

@interface MainController : NSObject {
@private
    IBOutlet NSWindow *window;
    IBOutlet NSTextField *titleTextField;
    IBOutlet NSTextField *textTextField;
    IBOutlet NSMatrix *notificationSystemMatrix;
    IBOutlet NSButton *afterDelayCheckBox;
    IBOutlet NSButton *postNotificationButton;
    IBOutlet NSButton *soundEnabledCheck;
    IBOutlet DRWUserNotificationCenterScreenCornerView *cornerView;
    IBOutlet NSSlider *durationSlider;

    NSTimer *growlAvailableCheckTimer;
}

- (void)dealloc;

- (void)awakeFromNib;

- (IBAction)showNotification:(id)sender;

- (void)updateSystemsState:(id)sender;
- (void)postNotification:(id)sender;

- (void)notificationClicked:(NSNotification*)notification;

@end

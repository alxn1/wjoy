//
//  DRWUserNotificationCenterScreenCornerView.m
//  NSystem
//
//  Created by alxn1 on 20.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWUserNotificationCenterScreenCornerView.h"

@implementation DRWUserNotificationCenterScreenCornerView

// MARK: public

+ (NSSize)bestSize
{
    return NSMakeSize(150.0f, 96.0f);
}

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if(self == nil) return nil;

    screenCorner = DRWUserNotificationCenterScreenCornerRightTop;
    isEnabled = YES;
    underMouseScreenCorner = -1;
    draggedMouseScreenCorner = -1;
    clickedMouseScreenCorner = -1;
    [self updateTrackingRects];

    return self;
}

- (id)initWithCoder:(NSCoder*)decoder
{
    self = [super initWithCoder:decoder];
    if(self == nil) return nil;

    screenCorner = DRWUserNotificationCenterScreenCornerRightTop;
    isEnabled = YES;
    underMouseScreenCorner = -1;
    draggedMouseScreenCorner = -1;
    clickedMouseScreenCorner = -1;
    [self updateTrackingRects];

    return self;
}

- (void)dealloc
{
    [self removeTrackingRects];
    [super dealloc];
}

- (void)drawRect:(NSRect)rect
{
    rect = [self bounds];

    [[NSImage imageNamed:@"screen"]
                            drawInRect:rect
                              fromRect:NSZeroRect
                             operation:NSCompositeSourceOver
                              fraction:1.0f];

    [[NSColor blackColor] setStroke];
    [[NSBezierPath bezierPathWithRect:rect] stroke];

    [self drawScreenCorner:DRWUserNotificationCenterScreenCornerLeftTop];
    [self drawScreenCorner:DRWUserNotificationCenterScreenCornerRightTop];
    [self drawScreenCorner:DRWUserNotificationCenterScreenCornerRightBottom];
    [self drawScreenCorner:DRWUserNotificationCenterScreenCornerLeftBottom];

    [[NSColor colorWithDeviceWhite:0.0f alpha:0.75f] setFill];
    [[self pathForCornerPoint] fill];

    if(![self isEnabled]) {
        [[NSColor colorWithDeviceWhite:1.0f alpha:0.35f] setFill];
        [[NSBezierPath bezierPathWithRect:rect] fill];
    }
}

- (void)setFrame:(NSRect)frameRect
{
    [super setFrame:frameRect];
    [self updateTrackingRects];
}

- (void)viewDidEndLiveResize
{
    [super viewDidEndLiveResize];
    [self updateTrackingRects];
}

- (void)mouseDown:(NSEvent*)event
{
    if(![self isEnabled]) return;
    draggedMouseScreenCorner = [self screenCornerFromEvent:event];
    clickedMouseScreenCorner = draggedMouseScreenCorner;
    if(draggedMouseScreenCorner >= 0) {
        [self setNeedsDisplay:YES];
    }
}

- (void)mouseDragged:(NSEvent*)event
{
    if(draggedMouseScreenCorner == -1) return;

    int corner = [self screenCornerFromEvent:event];
    if(corner != draggedMouseScreenCorner)
        corner = -1;

    if(clickedMouseScreenCorner != corner) {
        clickedMouseScreenCorner = corner;
        [self setNeedsDisplay:YES];
    }
}

- (void)mouseUp:(NSEvent*)event
{
    if(draggedMouseScreenCorner == -1) return;

    [self mouseDragged:event];
    draggedMouseScreenCorner = -1;
    if(clickedMouseScreenCorner >= 0) {
        [self setScreenCorner:(DRWUserNotificationCenterScreenCorner)clickedMouseScreenCorner];
        if(target != nil && action != nil) {
            [target performSelector:action withObject:self];
        }
        clickedMouseScreenCorner = -1;
        [self setNeedsDisplay:YES];
    }
}

- (void)mouseEntered:(NSEvent*)event
{
    if(![self isEnabled]) return;

    int corner = [self screenCornerFromEvent:event];
    if(underMouseScreenCorner != corner) {
        underMouseScreenCorner = corner;
        [self setNeedsDisplay:YES];
    }
}

- (void)mouseExited:(NSEvent*)event
{
    if(underMouseScreenCorner >= 0) {
        underMouseScreenCorner = -1;
        [self setNeedsDisplay:YES];
    }
}

- (BOOL)isEnabled
{
    return isEnabled;
}

- (void)setEnabled:(BOOL)enabled
{
    if(isEnabled == enabled) return;
    isEnabled = enabled;
    underMouseScreenCorner = -1;
    draggedMouseScreenCorner = -1;
    clickedMouseScreenCorner = -1;
    [self setNeedsDisplay:YES];
}

- (DRWUserNotificationCenterScreenCorner)screenCorner
{
    return screenCorner;
}

- (void)setScreenCorner:(DRWUserNotificationCenterScreenCorner)corner
{
    if(screenCorner == corner) return;
    screenCorner = corner;
    [self setNeedsDisplay:YES];
}

- (id)target
{
    return target;
}

- (void)setTarget:(id)obj
{
    target = obj;
}

- (SEL)action
{
    return action;
}

- (void)setAction:(SEL)sel
{
    action = sel;
}

// MARK: private

- (NSBezierPath*)pathForCornerPoint
{
    NSPoint point = NSZeroPoint;
    NSRect  rect  = [self bounds];

    switch(screenCorner) {
        case DRWUserNotificationCenterScreenCornerRightTop:
            point = NSMakePoint(rect.origin.x + rect.size.width - 8.0f, rect.origin.y + rect.size.height - 8.0f);
            break;

        case DRWUserNotificationCenterScreenCornerRightBottom:
            point = NSMakePoint(rect.origin.x + rect.size.width - 8.0f, rect.origin.y + 8.0f);
            break;

        case DRWUserNotificationCenterScreenCornerLeftBottom:
            point = NSMakePoint(rect.origin.x + 8.0f, rect.origin.y + 8.0f);
            break;

        case DRWUserNotificationCenterScreenCornerLeftTop:
            point = NSMakePoint(rect.origin.x + 8.0f, rect.origin.y + rect.size.height - 8.0f);
            break;
    }

    return [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(point.x - 2.0f, point.y - 2.0f, 4.0f, 4.0f)];
}

- (NSBezierPath*)pathForTriangle:(DRWUserNotificationCenterScreenCorner)corner
{
    NSBezierPath    *path = [NSBezierPath bezierPath];
    NSRect           rect = [self bounds];

    switch(corner) {
        case DRWUserNotificationCenterScreenCornerRightTop:
            [path moveToPoint:NSMakePoint(rect.origin.x + rect.size.width - 3.0f, rect.origin.y + rect.size.height - 3.0f)];
            [path lineToPoint:NSMakePoint(rect.origin.x + rect.size.width - 18.0f, rect.origin.y + rect.size.height - 3.0f)];
            [path lineToPoint:NSMakePoint(rect.origin.x + rect.size.width - 3.0f, rect.origin.y + rect.size.height - 18.0f)];
            break;

        case DRWUserNotificationCenterScreenCornerRightBottom:
            [path moveToPoint:NSMakePoint(rect.origin.x + rect.size.width - 3.0f, rect.origin.y + 3.0f)];
            [path lineToPoint:NSMakePoint(rect.origin.x + rect.size.width - 18.0f, rect.origin.y + 3.0f)];
            [path lineToPoint:NSMakePoint(rect.origin.x + rect.size.width - 3.0f, rect.origin.y + 18.0f)];
            break;

        case DRWUserNotificationCenterScreenCornerLeftBottom:
            [path moveToPoint:NSMakePoint(rect.origin.x + 3.0f, rect.origin.y + 3.0f)];
            [path lineToPoint:NSMakePoint(rect.origin.x + 18.0f, rect.origin.y + 3.0f)];
            [path lineToPoint:NSMakePoint(rect.origin.x + 3.0f, rect.origin.y + 18.0f)];
            break;

        case DRWUserNotificationCenterScreenCornerLeftTop:
            [path moveToPoint:NSMakePoint(rect.origin.x + 3.0f, rect.origin.y + rect.size.height - 3.0f)];
            [path lineToPoint:NSMakePoint(rect.origin.x + 18.0f, rect.origin.y + rect.size.height - 3.0f)];
            [path lineToPoint:NSMakePoint(rect.origin.x + 3.0f, rect.origin.y + rect.size.height - 18.0f)];
            break;
    }

    [path closePath];
    return path;
}

- (void)drawScreenCorner:(DRWUserNotificationCenterScreenCorner)corner
{
    float alphaValue = 0.5f;
    if(underMouseScreenCorner == corner) alphaValue = 0.75f;
    if(clickedMouseScreenCorner == corner) alphaValue = 0.6f;
    [[NSColor colorWithDeviceWhite:1.0f alpha:alphaValue] setFill];
    [[self pathForTriangle:corner] fill];
}

- (void)updateTrackingRects
{
    [self removeTrackingRects];

    NSPoint mousePosition = [self convertPoint:[[self window] mouseLocationOutsideOfEventStream]
                                      fromView:nil];

    NSBezierPath *path = [self pathForTriangle:DRWUserNotificationCenterScreenCornerLeftTop];
    trackingRectTags[0] = [self addTrackingRect:[path bounds]
                                          owner:self
                                       userData:nil
                                   assumeInside:[path containsPoint:mousePosition]];

    path = [self pathForTriangle:DRWUserNotificationCenterScreenCornerRightTop];
    trackingRectTags[1] = [self addTrackingRect:[path bounds]
                                          owner:self
                                       userData:nil
                                   assumeInside:[path containsPoint:mousePosition]];

    path = [self pathForTriangle:DRWUserNotificationCenterScreenCornerRightBottom];
    trackingRectTags[2] = [self addTrackingRect:[path bounds]
                                          owner:self
                                       userData:nil
                                   assumeInside:[path containsPoint:mousePosition]];

    path = [self pathForTriangle:DRWUserNotificationCenterScreenCornerLeftBottom];
    trackingRectTags[3] = [self addTrackingRect:[path bounds]
                                          owner:self
                                       userData:nil
                                   assumeInside:[path containsPoint:mousePosition]];
}

- (void)removeTrackingRects
{
    for(int i = 0; i < 4; i++) {
        if(trackingRectTags[i] != 0) {
            [self removeTrackingRect:trackingRectTags[i]];
            trackingRectTags[i] = 0;
        }
    }
}

- (int)screenCornerFromEvent:(NSEvent*)event
{
    NSPoint mousePosition = [self convertPoint:[event locationInWindow]
                                      fromView:nil];

    NSRect rect = [[self pathForTriangle:DRWUserNotificationCenterScreenCornerLeftTop] bounds];
    if(NSPointInRect(mousePosition, NSInsetRect(rect, -2.0f, -2.0f))) {
        return DRWUserNotificationCenterScreenCornerLeftTop;
    }

    rect = [[self pathForTriangle:DRWUserNotificationCenterScreenCornerRightTop] bounds];
    if(NSPointInRect(mousePosition, NSInsetRect(rect, -2.0f, -2.0f))) {
        return DRWUserNotificationCenterScreenCornerRightTop;
    }

    rect = [[self pathForTriangle:DRWUserNotificationCenterScreenCornerRightBottom] bounds];
    if(NSPointInRect(mousePosition, NSInsetRect(rect, -2.0f, -2.0f))) {
        return DRWUserNotificationCenterScreenCornerRightBottom;
    }

    rect = [[self pathForTriangle:DRWUserNotificationCenterScreenCornerLeftBottom] bounds];
    if(NSPointInRect(mousePosition, NSInsetRect(rect, -2.0f, -2.0f))) {
        return DRWUserNotificationCenterScreenCornerLeftBottom;
    }

    return -1;
}

@end

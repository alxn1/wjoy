//
//  DRWUserNotification.h
//  NSystem
//
//  Created by alxn1 on 18.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface DRWUserNotification : NSObject<NSCoding> {
@private
    NSString *title;
    NSString *text;
    NSDictionary *userInfo;
    NSInteger tag;
}

// MARK: public

+ (DRWUserNotification*)userNotificationWithTitle:(NSString*)aTitle text:(NSString*)aText;
+ (DRWUserNotification*)userNotificationWithTitle:(NSString*)aTitle text:(NSString*)aText tag:(NSInteger)aTag;
+ (DRWUserNotification*)userNotificationWithTitle:(NSString*)aTitle text:(NSString*)aText userInfo:(NSDictionary*)aUserInfo;
+ (DRWUserNotification*)userNotificationWithTitle:(NSString*)aTitle text:(NSString*)aText userInfo:(NSDictionary*)aUserInfo tag:(NSInteger)aTag;

- (id)initWithTitle:(NSString*)aTitle text:(NSString*)aText userInfo:(NSDictionary*)aUserInfo tag:(NSInteger)aTag;
- (id)initWithDictionary:(NSDictionary*)dictionary;
- (id)initWithCoder:(NSCoder*)decoder;
- (void)dealloc;

- (NSString*)title;
- (NSString*)text;
- (NSDictionary*)userInfo;
- (NSInteger)tag;

- (void)encodeWithCoder:(NSCoder*)coder;
- (NSDictionary*)asDictionary;
- (NSString*)description;

// MARK: private

- (void)checkFields;

@end

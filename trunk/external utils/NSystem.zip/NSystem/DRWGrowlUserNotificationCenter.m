//
//  DRWGrowlUserNotificationCenter.m
//  NSystem
//
//  Created by alxn1 on 18.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWGrowlUserNotificationCenter.h"
#import <Growl/Growl.h>

#define GrowlNotificationName   @"Notifications"

@interface DRWGrowlUserNotificationCenterGrowlDelegate : NSObject<GrowlApplicationBridgeDelegate> {
@private
    DRWGrowlUserNotificationCenter *owner;
}

- (id)initWithOwner:(DRWGrowlUserNotificationCenter*)obj;

- (NSDictionary*)registrationDictionaryForGrowl;
- (void)growlNotificationWasClicked:(id)clickContext;

@end

@implementation DRWGrowlUserNotificationCenterGrowlDelegate

- (id)initWithOwner:(DRWGrowlUserNotificationCenter*)obj
{
    self = [super init];
    if(self == nil) return nil;
    owner = obj;
    return self;
}

- (NSDictionary*)registrationDictionaryForGrowl
{
    NSDictionary *notifications = [NSDictionary dictionaryWithObject:GrowlNotificationName forKey:GrowlNotificationName];
    NSString     *appName       = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleDisplayName"];

    if(appName == nil) {
        appName = [[[NSBundle mainBundle] localizedInfoDictionary] objectForKey:(NSString *)kCFBundleNameKey];
        if(appName == nil) {
            appName = [[NSProcessInfo processInfo] processName];
        }
    }

	return [NSDictionary dictionaryWithObjectsAndKeys:
							 appName,                   GROWL_APP_NAME,
							 [notifications allKeys],   GROWL_NOTIFICATIONS_ALL,
							 [notifications allKeys],   GROWL_NOTIFICATIONS_DEFAULT,
							 notifications,             GROWL_NOTIFICATIONS_HUMAN_READABLE_NAMES,
							 nil];
}

- (void)growlNotificationWasClicked:(id)clickContext
{
    DRWUserNotification *notification = [[DRWUserNotification alloc] initWithDictionary:clickContext];
    [owner notificationClicked:notification];
    [notification release];
}

@end


@implementation DRWGrowlUserNotificationCenter

// MARK: public

+ (void)load
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    DRWGrowlUserNotificationCenter *center = [[DRWGrowlUserNotificationCenter alloc] init];
    [DRWUserNotificationCenter registerImpl:center];
    [center release];
    [pool release];
}

- (BOOL)isAvailable
{
    return [GrowlApplicationBridge isGrowlRunning];
}

- (NSString*)name
{
    return @"growl";
}

- (NSUInteger)merit
{
    return 1;
}

- (void)deliver:(DRWUserNotification*)notification
{
    if(![DRWUserNotificationCenter
                    shouldDeliverNotification:notification
                                       center:self]) {
        return;
    }

    [GrowlApplicationBridge
                notifyWithTitle:[notification title]
                    description:[notification text]
               notificationName:GrowlNotificationName
                       iconData:nil
                       priority:0
                       isSticky:NO
                   clickContext:[notification asDictionary]];
}

// MARK: private

- (id)init
{
    self = [super init];
    if(self == nil) return nil;

    growlDelegate = [[DRWGrowlUserNotificationCenterGrowlDelegate alloc] initWithOwner:self];
    [GrowlApplicationBridge setGrowlDelegate:growlDelegate];

    return self;
}

- (void)dealloc
{
    [GrowlApplicationBridge setGrowlDelegate:nil];
    [growlDelegate release];
    [super dealloc];
}

- (void)notificationClicked:(DRWUserNotification*)notification
{
    [DRWUserNotificationCenter notificationClicked:notification center:self];
}

@end

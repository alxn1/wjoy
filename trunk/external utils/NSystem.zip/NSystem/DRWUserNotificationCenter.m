//
//  DRWUserNotificationCenter.m
//  NSystem
//
//  Created by alxn1 on 18.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWUserNotificationCenter.h"

@implementation DRWUserNotificationCenter

static NSMutableArray *registredImpl = nil;
static id<DRWUserNotificationCenterDelegate> delegate = nil;
static BOOL isSoundEnabled = NO;
static NSString *soundName = nil;
static NSSound *sound = nil;

// MARK: public

+ (NSArray*)all
{
    return registredImpl;
}

+ (NSArray*)available
{
    NSMutableArray *result = [NSMutableArray array];
    NSUInteger countAvailable = [registredImpl count];
    for(NSUInteger i = 0; i < countAvailable; i++) {
        DRWUserNotificationCenter *center = [registredImpl objectAtIndex:i];
        if([center isAvailable]) {
            [result addObject:center];
        }
    }
    return result;
}

+ (DRWUserNotificationCenter*)best
{
    DRWUserNotificationCenter *result = nil;
    NSUInteger countAvailable = [registredImpl count];
    for(NSUInteger i = 0; i < countAvailable; i++) {
        DRWUserNotificationCenter *center = [registredImpl objectAtIndex:i];
        if([center isAvailable]) {
            if(result != nil) {
                if([center merit] < [result merit])
                    result = center;
            }
            else result = center;
        }
    }
    return result;
}

+ (DRWUserNotificationCenter*)withName:(NSString*)name
{
    DRWUserNotificationCenter *result = nil;
    NSUInteger countAvailable = [registredImpl count];
    for(NSUInteger i = 0; i < countAvailable; i++) {
        DRWUserNotificationCenter *center = [registredImpl objectAtIndex:i];
        if([[center name] isEqualToString:name]) {
            result = center;
            break;
        }
    }
    return result;
}

+ (BOOL)isSoundEnabled
{
    return isSoundEnabled;
}

+ (void)setSoundEnabled:(BOOL)enabled
{
    isSoundEnabled = enabled;
}

+ (NSString*)soundName
{
    return [[soundName retain] autorelease];
}

+ (void)setSoundName:(NSString*)name
{
    if(soundName == name) return;
    [soundName release];
    soundName = [name copy];
    [sound release];
    sound = [[NSSound soundNamed:name] retain];
}

+ (void)deliver:(DRWUserNotification*)notification
{
    [[DRWUserNotificationCenter best] deliver:notification];
}

+ (id<DRWUserNotificationCenterDelegate>)delegate
{
    return delegate;
}

+ (void)setDelegate:(id<DRWUserNotificationCenterDelegate>)obj
{
    delegate = obj;
}

- (BOOL)isAvailable
{
    return NO;
}

- (NSString*)name
{
    return @"";
}

- (NSUInteger)merit
{
    return NSUIntegerMax;
}

- (void)deliver:(DRWUserNotification*)notification
{
}

- (NSDictionary*)customSettings
{
    return nil;
}

- (void)setCustomSettings:(NSDictionary*)preferences
{
}

// MARK: protected

+ (void)registerImpl:(DRWUserNotificationCenter*)impl
{
    if(registredImpl == nil) {
        registredImpl = [[NSMutableArray alloc] init];
    }

    [registredImpl addObject:impl];
}

+ (BOOL)shouldDeliverNotification:(DRWUserNotification*)notification
                           center:(DRWUserNotificationCenter*)center
{
    BOOL result = YES;

    if([DRWUserNotificationCenter delegate] != nil) {
        result = [[DRWUserNotificationCenter delegate]
                                        userNotificationCenter:center
                                     shouldDeliverNotification:notification];
    }

    if(result && [DRWUserNotificationCenter isSoundEnabled]) {
        if(soundName != nil) {
             if(sound != nil) {
                if(![sound isPlaying]) [sound play];
             }
        }
        else NSBeep();
    }

    return result;
}

+ (void)notificationClicked:(DRWUserNotification*)notification
                     center:(DRWUserNotificationCenter*)center
{
    [self postClickedNotification:notification];

    [[DRWUserNotificationCenter delegate]
                         userNotificationCenter:center
                            notificationClicked:notification];
}

// MARK: private

+ (void)postClickedNotification:(DRWUserNotification*)notification
{
    [[NSNotificationCenter defaultCenter]
                        postNotificationName:DRWUserNotificationClickedNotification
                                      object:notification];
}

@end

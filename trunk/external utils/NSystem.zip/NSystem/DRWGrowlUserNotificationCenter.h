//
//  DRWGrowlUserNotificationCenter.h
//  NSystem
//
//  Created by alxn1 on 18.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWUserNotificationCenter.h"

@interface DRWGrowlUserNotificationCenter : DRWUserNotificationCenter {
@private
    NSObject *growlDelegate;
}

// MARK: public

+ (void)load;

- (BOOL)isAvailable;

- (NSString*)name;
- (NSUInteger)merit;

- (void)deliver:(DRWUserNotification*)notification;

// MARK: private

- (id)init;
- (void)dealloc;

- (void)notificationClicked:(DRWUserNotification*)notification;

@end

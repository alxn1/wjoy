//
//  DRWAppleUserNotificationCenter.m
//  NSystem
//
//  Created by alxn1 on 18.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWAppleUserNotificationCenter.h"

#define NSUserNotificationClassName                 @"NSUserNotification"
#define NSUserNotificationCenterClassName           @"NSUserNotificationCenter"

@protocol NSUserNotificationFutureProtocol

- (void)setTitle:(NSString*)title;
- (void)setInformativeText:(NSString*)text;
- (void)setSoundName:(NSString*)soundName;

- (NSDictionary*)userInfo;
- (void)setUserInfo:(NSDictionary*)userInfo;

@end

@protocol NSUserNotificationCenterFutureProtocol

+ (id<NSUserNotificationCenterFutureProtocol>)defaultUserNotificationCenter;

- (void)setDelegate:(id)obj;
- (void)deliverNotification:(id<NSUserNotificationFutureProtocol>)notification;
- (void)removeDeliveredNotification:(id<NSUserNotificationFutureProtocol>)notification;
- (void)removeAllDeliveredNotifications;

@end

@protocol NSUserNotificationDelegateFutureProtocol

- (void)userNotificationCenter:(id<NSUserNotificationCenterFutureProtocol>)center
        didDeliverNotification:(id<NSUserNotificationFutureProtocol>)notification;

- (void)userNotificationCenter:(id<NSUserNotificationCenterFutureProtocol>)center
       didActivateNotification:(id<NSUserNotificationFutureProtocol>)notification;

- (BOOL)userNotificationCenter:(id<NSUserNotificationCenterFutureProtocol>)center
     shouldPresentNotification:(id<NSUserNotificationFutureProtocol>)notification;

@end

@implementation DRWAppleUserNotificationCenter

// MARK: public

+ (void)load
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    if([DRWAppleUserNotificationCenter isAvailable]) {
        DRWAppleUserNotificationCenter *center = [[DRWAppleUserNotificationCenter alloc] init];
        [DRWUserNotificationCenter registerImpl:center];
        [center release];
    }
    [pool release];
}

- (BOOL)isAvailable
{
    return YES;
}

- (NSString*)name
{
    return @"apple";
}

- (NSUInteger)merit
{
    return 0;
}

- (void)deliver:(DRWUserNotification*)notification
{
    if(![DRWUserNotificationCenter
                    shouldDeliverNotification:notification
                                       center:self]) {
        return;
    }

    id<NSUserNotificationCenterFutureProtocol> center = [notificationCenterClass defaultUserNotificationCenter];
    id<NSUserNotificationFutureProtocol> n = [[[notificationClass alloc] init] autorelease];

    [n setInformativeText:[notification text]];
    [n setTitle:[notification title]];
    [n setSoundName:nil];
    [n setUserInfo:[notification asDictionary]];

    [center deliverNotification:n];
}

// MARK: private

+ (BOOL)isAvailable
{
    Class notificationClass = NSClassFromString(NSUserNotificationClassName);
    Class notificationCenterClass = NSClassFromString(NSUserNotificationCenterClassName);

    if(notificationCenterClass == nil ||
       notificationClass == nil) {
        return NO;
    }

    return YES;
}

- (id)init
{
    self = [super init];
    if(self == nil) return nil;

    notificationClass = NSClassFromString(NSUserNotificationClassName);
    notificationCenterClass = NSClassFromString(NSUserNotificationCenterClassName);

    [(id<NSUserNotificationCenterFutureProtocol>)
        [notificationCenterClass defaultUserNotificationCenter] setDelegate:self];

    [[NSNotificationCenter defaultCenter]
                                    addObserver:self
                                       selector:@selector(applicationWillTerminateNotification:)
                                           name:NSApplicationWillTerminateNotification
                                         object:nil];

    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [super dealloc];
}

- (void)userNotificationCenter:(id)center didActivateNotification:(id)notification
{
    DRWUserNotification *n = [[DRWUserNotification alloc] initWithDictionary:
                                    [(id<NSUserNotificationFutureProtocol>)notification userInfo]];

    [DRWUserNotificationCenter notificationClicked:n center:self];
    [n release];

    [(id<NSUserNotificationCenterFutureProtocol>)center
        removeDeliveredNotification:(id<NSUserNotificationFutureProtocol>)notification];
}

// MARK: NSApplication notifications

- (void)applicationWillTerminateNotification:(NSNotification*)notification
{
    [(id<NSUserNotificationCenterFutureProtocol>)
        [notificationCenterClass defaultUserNotificationCenter]
            removeAllDeliveredNotifications];
}

@end

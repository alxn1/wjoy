//
//  DRWOwnUserNotificationCenter.m
//  NSystem
//
//  Created by alxn1 on 18.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWOwnUserNotificationCenter.h"

@implementation DRWOwnUserNotificationCenter

// MARK: public

+ (void)load
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    DRWOwnUserNotificationCenter *center = [[DRWOwnUserNotificationCenter alloc] init];
    [DRWOwnUserNotificationCenter registerImpl:center];
    [center release];
    [pool release];
}

- (BOOL)isAvailable
{
    return YES;
}

- (NSString*)name
{
    return @"own";
}

- (NSUInteger)merit
{
    return 2;
}

- (void)deliver:(DRWUserNotification*)notification
{
    if(![DRWUserNotificationCenter
                    shouldDeliverNotification:notification
                                       center:self]) {
        return;
    }

    [[DRWNotificationSystem sharedInstance] deliver:notification];
}

- (NSDictionary*)customSettings
{
    return [NSDictionary dictionaryWithObjectsAndKeys:
                    [NSNumber numberWithDouble:[[DRWNotificationSystem sharedInstance] notificationTimeout]],
                    DRWUserNotificationCenterTimeoutKey,
                    [NSNumber numberWithInteger:[[DRWNotificationSystem sharedInstance] screenCorner]],
                    DRWUserNotificationCenterScreenCornerKey,
                    nil];
}

- (void)setCustomSettings:(NSDictionary*)preferences
{
    NSNumber *number = [preferences objectForKey:DRWUserNotificationCenterTimeoutKey];
    if(number != nil) {
        [[DRWNotificationSystem sharedInstance]
            setNotificationTimeout:[number doubleValue]];
    }

    number = [preferences objectForKey:DRWUserNotificationCenterScreenCornerKey];
    if(number != nil) {
        [[DRWNotificationSystem sharedInstance]
            setScreenCorner:
                (DRWUserNotificationCenterScreenCorner)[number integerValue]];
    }
}

// MARK: private

- (id)init
{
    self = [super init];
    if(self == nil)
        return nil;

    [[DRWNotificationSystem sharedInstance] setDelegate:self];

    return self;
}

// MARK: DRWNotificationSystemDelegate

- (void)notificationSystem:(DRWNotificationSystem*)system
       notificationClicked:(DRWUserNotification*)notification
{
    [DRWUserNotificationCenter notificationClicked:notification center:self];
}

@end

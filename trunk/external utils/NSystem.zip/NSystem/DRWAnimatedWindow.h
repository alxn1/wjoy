//
//  DRWAnimatedWindow.h
//  Scanner
//
//  Created by alxn1 on 26.10.11.
//  Copyright 2011 Dr. Web. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface DRWAnimatedWindow : NSWindow

#import "DRWAnimatedWindowBase.h"

@end

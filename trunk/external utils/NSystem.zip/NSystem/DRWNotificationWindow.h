//
//  DRWNotificationWindow.h
//  NSystem
//
//  Created by alxn1 on 19.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWAnimatedWindow.h"
#import "DRWUserNotification.h"
#import "DRWNotificationWindowView.h"

@interface DRWNotificationWindow : DRWAnimatedWindow<DRWNotificationWindowViewDelegate> {
@private
    DRWUserNotification *notification;
    NSTimer *autocloseTimer;

    BOOL isMouseEntered;
    BOOL isCloseOnMouseExited;

    id target;
    SEL action;
}

// MARK: public

+ (NSRect)bestRectForNotification:(DRWUserNotification*)aNotification;
+ (DRWNotificationWindow*)newWindowWithNotification:(DRWUserNotification*)aNotification frame:(NSRect)frame;

- (id)initWithNotification:(DRWUserNotification*)aNotification frame:(NSRect)frame;
- (void)dealloc;

- (id)target;
- (void)setTarget:(id)obj;

- (SEL)action;
- (void)setAction:(SEL)sel;

- (void)showWithTimeout:(NSTimeInterval)timeout;
- (void)close;

- (DRWUserNotification*)notification;

// MARK: NSWindow overrides

- (BOOL)canBecomeKeyWindow;
- (BOOL)canBecomeMainWindow;

// MARK: private

- (void)startAutocloseTimer:(NSTimeInterval)timeout;

- (void)autoclose:(id)sender;

- (void)contentViewClicked:(id)sender;

// MARK: DRWNotificationWindowViewDelegate

- (void)notificationWindowViewMouseEntered:(DRWNotificationWindowView*)view;
- (void)notificationWindowViewMouseExited:(DRWNotificationWindowView*)view;

@end

//
//  DRWRightBottomNotificationLayoutManager.h
//  NSystem
//
//  Created by alxn1 on 20.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "DRWNotificationLayoutManager.h"

@interface DRWRightBottomNotificationLayoutManager : DRWNotificationLayoutManager {
}

// MARK: public

- (DRWUserNotificationCenterScreenCorner)screenCorner;

// MARK: protected

- (BOOL)hasSpaceBeforeFirst:(NSRect)bestRect
        activeNotifications:(NSArray*)activeNotifications
                       rect:(NSRect*)resultRect;

- (BOOL)hasSpaceBetween:(NSRect)bestRect
              firstRect:(NSRect)firstRect
             secondRect:(NSRect)secondRect
    activeNotifications:(NSArray*)activeNotifications
                   rect:(NSRect*)resultRect;

- (BOOL)hasSpaceAfterLast:(NSRect)bestRect
      activeNotifications:(NSArray*)activeNotifications
                     rect:(NSRect*)resultRect;

@end

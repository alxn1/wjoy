//
//  WiimoteDeviceEventHandler.m
//  Wiimote
//
//  Created by alxn1 on 29.07.12.
//  Copyright (c) 2012 alxn1. All rights reserved.
//

#import "WiimoteDeviceEventHandler.h"

@interface WiimoteDeviceEventHandler (PrivatePart)

- (id)initWithTarget:(id)target
              action:(SEL)action
             oneShot:(BOOL)oneShot;

@end

@implementation WiimoteDeviceEventHandler

+ (WiimoteDeviceEventHandler*)newHandlerWithTarget:(id)target
                                            action:(SEL)action
                                           oneShot:(BOOL)oneShot
{
	return [[[WiimoteDeviceEventHandler alloc]
									initWithTarget:target
                                            action:action
                                           oneShot:oneShot] autorelease];
}

- (id)init
{
	[[super init] release];
	return nil;
}

- (BOOL)isOneShot
{
	return m_IsOneShot;
}

- (id)target
{
	return m_Target;
}

- (SEL)action
{
	return m_Action;
}

- (void)perform:(id)param
{
	if(m_Target != nil &&
	   m_Action	!= nil)
	{
		[m_Target performSelector:m_Action withObject:param];
	}
}

@end

@implementation WiimoteDeviceEventHandler (PrivatePart)

- (id)initWithTarget:(id)target
              action:(SEL)action
             oneShot:(BOOL)oneShot
{
	self = [super init];
	if(self == nil)
		return nil;

	m_Target	 = target;
	m_Action	 = action;
	m_IsOneShot	 = oneShot;

	return self;
}

@end

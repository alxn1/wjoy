//
//  Wiimote.h
//  Wiimote
//
//  Created by alxn1 on 29.07.12.
//  Copyright (c) 2012 alxn1. All rights reserved.
//

#import <Foundation/Foundation.h>

#define WiimoteButtonCount 11

typedef enum
{
    WiimoteButtonTypeLeft       =  0,
    WiimoteButtonTypeRight      =  1,
    WiimoteButtonTypeUp         =  2,
    WiimoteButtonTypeDown       =  3,
    WiimoteButtonTypeA          =  4,
    WiimoteButtonTypeB          =  5,
    WiimoteButtonTypePlus       =  6,
    WiimoteButtonTypeMinus      =  7,
    WiimoteButtonTypeHome       =  8,
    WiimoteButtonTypeOne        =  9,
    WiimoteButtonTypeTwo        = 10
} WiimoteButtonType;

typedef enum
{
    WiimoteLEFlagDOne			=  1,
    WiimoteLEDFlagTwo			=  2,
    WiimoteLEDFlagThree			=  4,
    WiimoteLEDFlagFour			=  8
} WiimoteLEDFlag;

FOUNDATION_EXPORT NSString *WiimoteBeginDiscoveryNotification;
FOUNDATION_EXPORT NSString *WiimoteEndDiscoveryNotification;

FOUNDATION_EXPORT NSString *WiimoteConnectedNotification;
FOUNDATION_EXPORT NSString *WiimoteButtonPresedNotification;
FOUNDATION_EXPORT NSString *WiimoteButtonReleasedNotification;
FOUNDATION_EXPORT NSString *WiimoteHighlightedLEDMaskChangedNotification;
FOUNDATION_EXPORT NSString *WiimoteVibrationStateChangedNotification;
FOUNDATION_EXPORT NSString *WiimoteBatteryLevelUpdatedNotification;
FOUNDATION_EXPORT NSString *WiimoteExtensionConnectedNotification;
FOUNDATION_EXPORT NSString *WiimoteExtensionDisconnectedNotification;
FOUNDATION_EXPORT NSString *WiimoteDisconnectedNotification;

FOUNDATION_EXPORT NSString *WiimoteButtonKey;
FOUNDATION_EXPORT NSString *WiimoteHighlightedLEDMaskKey;
FOUNDATION_EXPORT NSString *WiimoteVibrationStateKey;
FOUNDATION_EXPORT NSString *WiimoteBatteryLevelKey;
FOUNDATION_EXPORT NSString *WiimoteIsBatteryLevelLowKey;
FOUNDATION_EXPORT NSString *WiimoteExtensionKey;

@class WiimoteDevice;
@class WiimoteExtension;
@class Wiimote;

@protocol WiimoteDelegate

- (void)wiimote:(Wiimote*)wiimote buttonPressed:(WiimoteButtonType)button;
- (void)wiimote:(Wiimote*)wiimote buttonReleased:(WiimoteButtonType)button;
- (void)wiimote:(Wiimote*)wiimote highlightedLEDMaskChanged:(NSUInteger)mask;
- (void)wiimote:(Wiimote*)wiimote vibrationStateChanged:(BOOL)isVibrationEnabled;
- (void)wiimote:(Wiimote*)wiimote batteryLevelUpdated:(double)batteryLevel isLow:(BOOL)isLow;
- (void)wiimot:(Wiimote*)wiimote extensionConnected:(WiimoteExtension*)extension;
- (void)wiimote:(Wiimote*)wiimote extensionDisconnected:(WiimoteExtension*)extension;
- (void)wiimoteDisconnected:(Wiimote*)wiimote;

@end

@interface Wiimote : NSObject
{
	@private
		WiimoteDevice		*m_Device;

		BOOL				 m_IsStateChangeNotificationsEnabled;

        NSUInteger			 m_HighlightedLEDMask;
        BOOL				 m_IsVibrationEnabled;
        BOOL				 m_IsInitialiased;

        BOOL				 m_ButtonState[WiimoteButtonCount];

        double				 m_BatteryLevel;
        BOOL				 m_IsBatteryLevelLow;
        BOOL				 m_IsUpdateStateStarted;

		NSDictionary		*m_UserInfo;

        id<WiimoteDelegate>	 m_Delegate;
}

+ (BOOL)isBluetoothEnabled;

+ (BOOL)isDiscovering;
+ (BOOL)beginDiscovery;

+ (NSArray*)connectedDevices;

- (BOOL)isConnected;
- (void)disconnect;

- (NSData*)address;
- (NSString*)addressString;

// or'ed WiimoteLED flags
- (NSUInteger)highlightedLEDMask;
- (void)setHighlightedLEDMask:(NSUInteger)mask;

- (BOOL)isVibrationEnabled;
- (void)setVibrationEnabled:(BOOL)enabled;

- (BOOL)isButtonPressed:(WiimoteButtonType)button;

- (double)batteryLevel; // 0.0 - 100.0 %, or -1 if undefined
- (BOOL)isBatteryLevelLow;
- (void)updateState;

// disable all notifications, except begin/end discovery, battery level and connect/disconnect
- (BOOL)isStateChangeNotificationsEnabled;
- (void)setStateChangeNotificationsEnabled:(BOOL)enabled;

- (NSDictionary*)userInfo;
- (void)setUserInfo:(NSDictionary*)userInfo;

- (id<WiimoteDelegate>)delegate;
- (void)setDelegate:(id<WiimoteDelegate>)delegate;

@end

//
//  WiimoteDevice.m
//  Wiimote
//
//  Created by alxn1 on 29.07.12.
//  Copyright (c) 2012 alxn1. All rights reserved.
//

#import "WiimoteDevice.h"
#import "WiimoteDeviceReportHandler.h"
#import "WiimoteDeviceReadMemHandler.h"
#import <IOBluetooth/IOBluetooth.h>

@interface WiimoteDevice (PrivatePart)

- (id)initWithBluetoothDevice:(IOBluetoothDevice*)device;

- (IOBluetoothL2CAPChannel*)openChannel:(BluetoothL2CAPPSM)channelID;

- (void)handleReport:(WiimoteDeviceReport*)report;
- (void)handleDisconnect;

@end

@interface WiimoteDevice (IOBluetoothL2CAPChannelDelegate)

- (void)l2capChannelData:(IOBluetoothL2CAPChannel*)l2capChannel
                    data:(void*)dataPointer
                  length:(size_t)dataLength;

- (void)l2capChannelClosed:(IOBluetoothL2CAPChannel*)l2capChannel;

@end

@implementation WiimoteDevice

+ (WiimoteDevice*)wrapBluetoothDevice:(IOBluetoothDevice*)device
{
	return [[[WiimoteDevice alloc] initWithBluetoothDevice:device] autorelease];
}

- (id)init
{
	[[super init] release];
	return nil;
}

- (void)dealloc
{
	[self disconnect];
	[m_DisconnectHandlers release];
	[m_AllReportHandlers release];
	[m_ReportHandlersMap release];
	[m_ControlChannel release];
	[m_DataChannel release];
	[m_Device release];
	[super dealloc];
}

- (BOOL)isConnected
{
	return m_IsConnected;
}

- (BOOL)connect
{
	if([self isConnected])
		return YES;

	m_IsConnected		= YES;
	m_ControlChannel	= [[self openChannel:kBluetoothL2CAPPSMHIDControl] retain];
	m_DataChannel		= [[self openChannel:kBluetoothL2CAPPSMHIDInterrupt] retain];

	if(m_ControlChannel == nil ||
       m_DataChannel    == nil)
    {
		[self disconnect];
		m_IsConnected = NO;
        return NO;
    }

	return YES;
}

- (void)disconnect
{
	if(![self isConnected])
		return;

	[m_ControlChannel setDelegate:nil];
	[m_DataChannel setDelegate:nil];

	[m_ControlChannel closeChannel];
	[m_DataChannel closeChannel];
	[m_Device closeConnection];

	m_IsConnected = NO;

	[self handleDisconnect];
	[self removeAllHandlers];
}

- (NSData*)address
{
	if(![self isConnected])
		return nil;

	const BluetoothDeviceAddress *address = [m_Device getAddress];
    if(address == NULL)
        return nil;

    return [NSData dataWithBytes:address->data
                          length:sizeof(address->data)];
}

- (NSString*)addressString
{
	if(![self isConnected])
		return nil;

	return [m_Device addressString];
}

- (BOOL)postCommand:(WiimoteDeviceCommandType)command
			   data:(NSData*)data
{
	if(![self isConnected])
		return NO;

	unsigned char buffer[[data length] + 2];

    buffer[0] = WiimoteDevicePacketTypeCommand;
    buffer[1] = command;
    memcpy(buffer + 2, [data bytes], [data length]);

    return ([m_DataChannel writeSync:buffer length:sizeof(buffer)] == kIOReturnSuccess);
}

- (BOOL)writeMemory:(NSUInteger)address
			   data:(NSData*)data
	 vibrationState:(BOOL)vibrationState
{
	if(![self isConnected] ||
		[data length] > WiimoteDeviceWriteMemotyDataSize)
	{
		return NO;
	}

	if([data length] == 0)
		return YES;

	uint32_t	   addr			= OSSwapHostToBigInt32(address);
	uint8_t		   len			= [data length];
	NSMutableData *commandData	= [NSMutableData dataWithLength:WiimoteDeviceWriteMemotyDataSize + 5];
	unsigned char *buffer		= [commandData mutableBytes];

	memcpy(buffer, &addr, sizeof(addr));
	memcpy(buffer + sizeof(addr), &len, sizeof(len));
	memset(buffer + sizeof(addr) + sizeof(len), 0, WiimoteDeviceWriteMemotyDataSize);
	memcpy(buffer + sizeof(addr) + sizeof(len), [data bytes], [data length]);

	if(vibrationState)
        buffer[0] |= WiimoteDeviceCommandFlagVibraEnabled;

	return [self postCommand:WiimoteDeviceCommandTypeWriteMemory
						data:commandData];
}

- (BOOL)readMemory:(NSRange)memoryRange
	vibrationState:(BOOL)vibrationState
			target:(id)target
			action:(SEL)action
{
	if(![self isConnected])
		return NO;

	WiimoteDeviceReadMemHandler *handler =
			[[WiimoteDeviceReadMemHandler alloc]
									initWithMemoryRange:memoryRange
												 target:target
												 action:action];

	[handler setAutorelease:YES];
	if(![handler startWithDevice:self vibrationState:vibrationState])
	{
		[handler release];
		return NO;
	}

	return YES;
}

@end

@implementation WiimoteDevice (ReportHandling)

- (void)addReportTypeHandler:(WiimoteDeviceReportType)reportType
					  target:(id)target
					  action:(SEL)action
					 oneShot:(BOOL)oneShot
{
	if(![self isConnected])
		return;

	NSNumber		*key		= [NSNumber numberWithInteger:reportType];
	NSMutableArray	*handlers	= [m_ReportHandlersMap objectForKey:key];

	if(handlers == nil)
	{
		handlers = [[NSMutableArray alloc] init];
		[m_ReportHandlersMap setObject:handlers forKey:key];
		[handlers release];
	}

	[handlers addObject:
				[WiimoteDeviceReportHandler
							newHandlerWithReportType:reportType
											  target:target
											  action:action
											 oneShot:oneShot]];
}

- (void)removeReportTypeHandler:(id)target
{
	NSArray		*allHandlers		= [m_ReportHandlersMap allValues];
	NSUInteger	 countAllHandlers	= [allHandlers count];

	for(NSUInteger i = 0; i < countAllHandlers; i++)
	{
		NSMutableArray *handlers		= [allHandlers objectAtIndex:i];
		NSUInteger		countHandlers	= [handlers count];

		for(NSUInteger j = 0; j < countHandlers; j++)
		{
			WiimoteDeviceReportHandler *handler = [handlers objectAtIndex:j];
			if([handler target] == target)
			{
				[handlers removeObjectAtIndex:j];
				j--;
			}
		}
	}
}

- (void)removeReportTypeHandler:(WiimoteDeviceReportType)reportType
						 target:(id)target
						 action:(SEL)action
{
	NSMutableArray	*handlers		= [m_ReportHandlersMap objectForKey:[NSNumber numberWithInteger:reportType]];
	NSUInteger		 countHandlers	= [handlers count];

	for(NSUInteger i = 0; i < countHandlers; i++)
	{
		WiimoteDeviceReportHandler *handler = [handlers objectAtIndex:i];

		if([handler target] == target &&
		   [handler action] == action)
		{
			[handlers removeObjectAtIndex:i];
			i--;
		}
	}
}

- (void)addReportHandler:(id)target action:(SEL)action oneShot:(BOOL)oneShot
{
	[m_AllReportHandlers addObject:
		[WiimoteDeviceReportHandler
			newHandlerWithReportType:WiimoteDeviceReportTypeUnknown
							  target:target
							  action:action
							 oneShot:oneShot]];
}

- (void)removeReportHandler:(id)target action:(SEL)action
{
	NSUInteger countHandlers = [m_AllReportHandlers count];

	for(NSUInteger i = 0; i < countHandlers; i++)
	{
		WiimoteDeviceReportHandler *handler = [m_AllReportHandlers objectAtIndex:i];

		if([handler target] == target &&
		   [handler action] == action)
		{
			[m_AllReportHandlers removeObjectAtIndex:i];
			i--;
		}
	}
}

- (void)removeReportHandler:(id)target
{
	NSUInteger countHandlers = [m_AllReportHandlers count];

	for(NSUInteger i = 0; i < countHandlers; i++)
	{
		WiimoteDeviceReportHandler *handler = [m_AllReportHandlers objectAtIndex:i];

		if([handler target] == target)
		{
			[m_AllReportHandlers removeObjectAtIndex:i];
			i--;
		}
	}
}

- (void)addDisconnectHandler:(id)target action:(SEL)action oneShot:(BOOL)oneShot
{
	[m_DisconnectHandlers addObject:
		[WiimoteDeviceReportHandler
			newHandlerWithReportType:WiimoteDeviceReportTypeUnknown
							  target:target
							  action:action
							 oneShot:oneShot]];
}

- (void)removeDisconnectHandler:(id)target action:(SEL)action
{
	NSUInteger countHandlers = [m_DisconnectHandlers count];

	for(NSUInteger i = 0; i < countHandlers; i++)
	{
		WiimoteDeviceReportHandler *handler = [m_DisconnectHandlers objectAtIndex:i];

		if([handler target] == target &&
		   [handler action] == action)
		{
			[m_DisconnectHandlers removeObjectAtIndex:i];
			i--;
		}
	}
}

- (void)removeDisconnectHandler:(id)target
{
	NSUInteger countHandlers = [m_DisconnectHandlers count];

	for(NSUInteger i = 0; i < countHandlers; i++)
	{
		WiimoteDeviceReportHandler *handler = [m_DisconnectHandlers objectAtIndex:i];

		if([handler target] == target)
		{
			[m_DisconnectHandlers removeObjectAtIndex:i];
			i--;
		}
	}
}

- (void)removeAllHandlers
{
	[m_DisconnectHandlers removeAllObjects];
	[m_AllReportHandlers removeAllObjects];
	[m_ReportHandlersMap removeAllObjects];
}

@end

@implementation WiimoteDevice (PrivatePart)

- (id)initWithBluetoothDevice:(IOBluetoothDevice*)device
{
	self = [super init];
	if(self == nil)
		return nil;

	if(device == nil)
	{
		[self release];
		return nil;
	}

	m_Device				= [device retain];
	m_DataChannel			= nil;
	m_ControlChannel		= nil;
	m_ReportHandlersMap		= [[NSMutableDictionary alloc] init];
	m_AllReportHandlers		= [[NSMutableArray alloc] init];
	m_DisconnectHandlers	= [[NSMutableArray alloc] init];
	m_IsConnected			= NO;

	return self;
}

- (IOBluetoothL2CAPChannel*)openChannel:(BluetoothL2CAPPSM)channelID
{
	IOBluetoothL2CAPChannel *result = nil;

	if([m_Device openL2CAPChannelSync:&result
                              withPSM:channelID
                             delegate:self] != kIOReturnSuccess)
    {
		return nil;
    }

	return result;
}

- (void)handleReport:(WiimoteDeviceReport*)report
{
	{
		NSUInteger countHandlers = [m_AllReportHandlers count];

		for(NSUInteger i = 0; i < countHandlers; i++)
		{
			WiimoteDeviceReportHandler *handler = [m_AllReportHandlers objectAtIndex:i];

			[handler performWithReport:report];
			if([handler isOneShot])
			{
				[m_AllReportHandlers removeObjectAtIndex:i];
				i--;
			}
		}
	}

	{
		NSMutableArray	*handlers		= [m_ReportHandlersMap objectForKey:[NSNumber numberWithInteger:[report type]]];
		NSUInteger		 countHandlers	= [handlers count];

		for(NSUInteger i = 0; i < countHandlers; i++)
		{
			WiimoteDeviceReportHandler *handler = [handlers objectAtIndex:i];

			[handler performWithReport:report];
			if([handler isOneShot])
			{
				[handlers removeObjectAtIndex:i];
				i--;
			}
		}
	}
}

- (void)handleDisconnect
{
	NSUInteger countHandlers = [m_DisconnectHandlers count];

	for(NSUInteger i = 0; i < countHandlers; i++)
	{
		WiimoteDeviceReportHandler *handler = [m_DisconnectHandlers objectAtIndex:i];

		[handler performWithReport:self];
		if([handler isOneShot])
		{
			[m_DisconnectHandlers removeObjectAtIndex:i];
			i--;
		}
	}
}

@end

@implementation WiimoteDevice (IOBluetoothL2CAPChannelDelegate)

- (void)l2capChannelData:(IOBluetoothL2CAPChannel*)l2capChannel
                    data:(void*)dataPointer
                  length:(size_t)dataLength
{
	WiimoteDeviceReport *report = [WiimoteDeviceReport
											parseReportData:dataPointer
													 length:dataLength
													 device:self];

	if(report == nil)
	{
		[self disconnect];
		return;
	}

	[self handleReport:report];
}

- (void)l2capChannelClosed:(IOBluetoothL2CAPChannel*)l2capChannel
{
    [self disconnect];
}

@end

//
//  WiimoteDeviceReport.m
//  Wiimote
//
//  Created by alxn1 on 29.07.12.
//  Copyright (c) 2012 alxn1. All rights reserved.
//

#import "WiimoteDeviceReport.h"

@interface WiimoteDeviceReport (PrivatePart)

+ (WiimoteDeviceReportType)parseReportType:(unsigned char)reportType;

- (id)initWithReportData:(const unsigned char*)data
				  length:(NSUInteger)length
				  device:(WiimoteDevice*)device;

@end

@implementation WiimoteDeviceReport

+ (WiimoteDeviceReport*)parseReportData:(const unsigned char*)data
								 length:(NSUInteger)length
								 device:(WiimoteDevice*)device
{
	return [[[WiimoteDeviceReport alloc]
							initWithReportData:data
										length:length
										device:device] autorelease];
}

- (id)init
{
	[[super init] release];
	return nil;
}

- (void)dealloc
{
	[m_Data release];
	[m_Device release];
	[super dealloc];
}

- (NSData*)data
{
	return [[m_Data retain] autorelease];
}

- (WiimoteDeviceReportType)type
{
	return m_Type;
}

- (WiimoteDevice*)device
{
	return [[m_Device retain] autorelease];
}

@end

@implementation WiimoteDeviceReport (PrivatePart)

+ (WiimoteDeviceReportType)parseReportType:(unsigned char)reportType
{
	switch(reportType)
	{
		case WiimoteDeviceReportTypeStatus:
		case WiimoteDeviceReportTypeDataReaded:
		case WiimoteDeviceReportTypeAcknowledge:
		case WiimoteDeviceReportTypeCoreButtons:
		case WiimoteDeviceReportTypeCoreButtonsAndExtStat:
			return (WiimoteDeviceReportType)reportType;
	}

	return WiimoteDeviceReportTypeUnknown;
}

- (id)initWithReportData:(const unsigned char*)data
				  length:(NSUInteger)length
				  device:(WiimoteDevice*)device
{
	self = [super init];
	if(self == nil)
		return nil;

	if(device	== nil ||
	   data		== NULL ||
	   length < WiimoteDeviceReportHeaderSize ||
	   data[0]	!= WiimoteDevicePacketTypeReport)
	{
		[self release];
		return nil;
	}

	m_Type		= [WiimoteDeviceReport parseReportType:data[1]];
	m_Device	= [device retain];
	m_Data		= [[NSData alloc]
						initWithBytes:data + WiimoteDeviceReportHeaderSize
							   length:length - WiimoteDeviceReportHeaderSize];

	return self;
}

@end

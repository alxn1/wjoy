//
//  WiimoteDeviceReportHandler.m
//  Wiimote
//
//  Created by alxn1 on 29.07.12.
//  Copyright (c) 2012 alxn1. All rights reserved.
//

#import "WiimoteDeviceReportHandler.h"

@interface WiimoteDeviceReportHandler (PrivatePart)

- (id)initWithReportType:(WiimoteDeviceReportType)reportType
				  target:(id)target
				  action:(SEL)action
				 oneShot:(BOOL)oneShot;

@end

@implementation WiimoteDeviceReportHandler

+ (WiimoteDeviceReportHandler*)newHandlerWithReportType:(WiimoteDeviceReportType)reportType
												 target:(id)target
												 action:(SEL)action
												oneShot:(BOOL)oneShot
{
	return [[[WiimoteDeviceReportHandler alloc]
									initWithReportType:reportType
												target:target
												action:action
											   oneShot:oneShot] autorelease];
}

- (id)init
{
	[[super init] release];
	return nil;
}

- (BOOL)isOneShot
{
	return m_IsOneShot;
}

- (WiimoteDeviceReportType)reportType
{
	return m_ReportType;
}

- (id)target
{
	return m_Target;
}

- (SEL)action
{
	return m_Action;
}

- (void)performWithReport:(id)report
{
	if(m_Target != nil &&
	   m_Action	!= nil)
	{
		[m_Target performSelector:m_Action withObject:report];
	}
}

@end

@implementation WiimoteDeviceReportHandler (PrivatePart)

- (id)initWithReportType:(WiimoteDeviceReportType)reportType
				  target:(id)target
				  action:(SEL)action
				 oneShot:(BOOL)oneShot
{
	self = [super init];
	if(self == nil)
		return nil;

	m_ReportType = reportType;
	m_Target	 = target;
	m_Action	 = action;
	m_IsOneShot	 = oneShot;

	return self;
}

@end

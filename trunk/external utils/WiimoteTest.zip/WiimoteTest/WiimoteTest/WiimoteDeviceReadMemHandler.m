//
//  WiimoteDeviceReadMemHandler.m
//  Wiimote
//
//  Created by alxn1 on 29.07.12.
//  Copyright (c) 2012 alxn1. All rights reserved.
//

#import "WiimoteDeviceReadMemHandler.h"
#import "WiimoteDevice.h"

@implementation WiimoteDeviceReadMemHandler

- (id)init
{
	[[super init] release];
	return nil;
}

- (id)initWithMemoryRange:(NSRange)memoryRange
				   target:(id)target
				   action:(SEL)action
{
	self = [super init];
	if(self == nil)
		return nil;

	m_Device		= nil;
	m_MemoryRange	= memoryRange;
	m_ReadedData	= [[NSMutableData alloc] initWithCapacity:memoryRange.length];
	m_IsFinished	= NO;
	m_IsAutorelease	= YES;
	m_Target		= [target retain];
	m_Action		= action;

	if(memoryRange.length == 0)
	{
		[self release];
		return nil;
	}

	return self;
}

- (void)dealloc
{
	[m_Device removeReportTypeHandler:self];
	[m_Device removeDisconnectHandler:self];
	[m_ReadedData release];
	[m_Target release];
	[super dealloc];
}

- (BOOL)startWithDevice:(WiimoteDevice*)device
		 vibrationState:(BOOL)vibrationState
{
	if(m_Device != nil ||
	   device	== nil ||
	   ![device isConnected])
	{
		return NO;
	}

	m_Device = device;

	uint32_t address	= (uint32_t)m_MemoryRange.location;
	uint16_t length		= m_MemoryRange.length;

	OSSwapHostToBigInt32(address);
	OSSwapHostToBigInt16(length);

	NSMutableData *commandData	= [NSMutableData dataWithLength:6];
	unsigned char *data			= [commandData mutableBytes];

	memcpy(data, &address, sizeof(address));
	memcpy(data + sizeof(address), &length, sizeof(length));

	if(vibrationState)
        data[0] |= WiimoteDeviceCommandFlagVibraEnabled;

	if(![m_Device postCommand:WiimoteDeviceCommandTypeReadMemory
						 data:commandData])
	{
		return NO;
	}

	[m_Device addDisconnectHandler:self
							action:@selector(deviceDisconnected:)
						   oneShot:NO];

	[m_Device addReportTypeHandler:WiimoteDeviceReportTypeDataReaded
							target:self
							action:@selector(deviceReadDataReport:)
						   oneShot:NO];

	return YES;
}

- (BOOL)isAutorelease
{
	return m_IsAutorelease;
}

- (void)setAutorelease:(BOOL)flag
{
	m_IsAutorelease = flag;
}

- (void)readFinished
{
	if(m_IsFinished)
		return;

	m_IsFinished = YES;
	[self performSelector:@selector(allDataReaded) withObject:nil afterDelay:0.0];
}

- (void)deviceDisconnected:(WiimoteDevice*)device
{
	[m_Device removeReportTypeHandler:self];
	[m_Device removeDisconnectHandler:self];
	m_Device = nil;

	if(m_IsAutorelease)
		[self release];
}

- (void)deviceReadDataReport:(WiimoteDeviceReport*)report
{
	if([[report data] length] < WiimoteDeviceMinReadMemoryReportSize)
		return;

	NSData				*data			= [report data];
	const unsigned char *buffer			= (const unsigned char*)[data bytes];
	uint16_t			 offset			= *((uint16_t*)&(buffer[3]));

	OSSwapBigToHostInt16(offset);

	uint32_t			 address		= (uint32_t)(m_MemoryRange.location + offset);
	uint32_t			 desiredAddress	= (uint32_t)(m_MemoryRange.location + [m_ReadedData length]);

	if(address != desiredAddress)
		return;

	if((buffer[2] & 0xF0) != 0)
	{
		[self readFinished];
		return;
	}

	[m_ReadedData appendBytes:buffer + WiimoteDeviceMinReadMemoryReportSize
					   length:[data length] - WiimoteDeviceMinReadMemoryReportSize];

	if([m_ReadedData length] >= m_MemoryRange.length)
		[self readFinished];
}

- (void)allDataReaded
{
	[m_Device removeReportTypeHandler:self];
	[m_Device removeDisconnectHandler:self];

	if(m_Target != nil &&
	   m_Action != nil)
	{
		[m_Target performSelector:m_Action withObject:m_ReadedData];
		[m_Target release];
		m_Target = nil;
	}

	if(m_IsAutorelease)
		[self release];
}

@end

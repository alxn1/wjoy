//
//  WiimoteDeviceReport.h
//  Wiimote
//
//  Created by alxn1 on 29.07.12.
//  Copyright (c) 2012 alxn1. All rights reserved.
//

#import "WiimoteProtocol.h"

@class WiimoteDevice;

@interface WiimoteDeviceReport : NSObject
{
	@private
		NSData					*m_Data;
		WiimoteDeviceReportType	 m_Type;
		WiimoteDevice			*m_Device;
}

+ (WiimoteDeviceReport*)parseReportData:(const unsigned char*)data
								 length:(NSUInteger)length
								 device:(WiimoteDevice*)device;

- (NSData*)data;
- (WiimoteDeviceReportType)type;
- (WiimoteDevice*)device;

@end

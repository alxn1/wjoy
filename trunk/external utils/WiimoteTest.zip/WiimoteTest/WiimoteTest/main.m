//
//  main.m
//  WiimoteTest
//
//  Created by Александр Серков on 29.07.12.
//  Copyright (c) 2012 Александр Серков. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	NSLog(@"Started!");
	[pool release];
    return 0;
}


//
//  WiimoteDeviceReportHandler.h
//  Wiimote
//
//  Created by alxn1 on 29.07.12.
//  Copyright (c) 2012 alxn1. All rights reserved.
//

#import "WiimoteDeviceReport.h"

@interface WiimoteDeviceReportHandler : NSObject
{
	@private
		WiimoteDeviceReportType	m_ReportType;
		id						m_Target;
		SEL						m_Action;
		BOOL					m_IsOneShot;
}

+ (WiimoteDeviceReportHandler*)newHandlerWithReportType:(WiimoteDeviceReportType)reportType
												 target:(id)target
												 action:(SEL)action
												oneShot:(BOOL)oneShot;

- (BOOL)isOneShot;
- (WiimoteDeviceReportType)reportType;

- (id)target;
- (SEL)action;

- (void)performWithReport:(id)report;

@end

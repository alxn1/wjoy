//
//  Wiimote.h
//  Wiimote
//
//  Created by alxn1 on 29.07.12.
//  Copyright (c) 2012 alxn1. All rights reserved.
//

#import "WiimoteDelegate.h"

FOUNDATION_EXPORT NSString *WiimoteBeginDiscoveryNotification;
FOUNDATION_EXPORT NSString *WiimoteEndDiscoveryNotification;

@class WiimotePart;
@class WiimotePartSet;
@class WiimoteDevice;

@interface Wiimote : NSObject
{
	@private
		WiimoteDevice		*m_Device;
        WiimotePartSet      *m_Parts;

		NSDictionary		*m_UserInfo;
}

+ (BOOL)isBluetoothEnabled;

+ (BOOL)isDiscovering;
+ (BOOL)beginDiscovery;

+ (NSArray*)connectedDevices;

- (BOOL)isConnected;
- (void)disconnect;

- (NSData*)address;
- (NSString*)addressString;

- (void)requestUpdateState;

// disable all notifications, except begin/end discovery, battery level and connect/disconnect
- (BOOL)isStateChangeNotificationsEnabled;
- (void)setStateChangeNotificationsEnabled:(BOOL)enabled;

- (NSDictionary*)userInfo;
- (void)setUserInfo:(NSDictionary*)userInfo;

- (id)delegate;
- (void)setDelegate:(id)delegate;

@end

@interface Wiimote (LED)

// or'ed WiimoteLED flags
- (NSUInteger)highlightedLEDMask;
- (void)setHighlightedLEDMask:(NSUInteger)mask;

@end

@interface Wiimote (Vibration)

- (BOOL)isVibrationEnabled;
- (void)setVibrationEnabled:(BOOL)enabled;

@end

@interface Wiimote (Button)

- (BOOL)isButtonPressed:(WiimoteButtonType)button;

@end

@interface Wiimote (Battery)

- (double)batteryLevel; // 0.0 - 100.0 %, or -1 if undefined
- (BOOL)isBatteryLevelLow;

@end

@interface Wiimote (Parts)

- (WiimotePart*)partWithClass:(Class)cls;

@end

// unimplemented part

/*FOUNDATION_EXPORT NSString *WiimoteExtensionConnectedNotification;
FOUNDATION_EXPORT NSString *WiimoteExtensionDisconnectedNotification;

FOUNDATION_EXPORT NSString *WiimoteExtensionKey;*/

/*@protocol WiimoteDelegate

- (void)wiimote:(Wiimote*)wiimote extensionConnected:(WiimoteExtension*)extension;
- (void)wiimote:(Wiimote*)wiimote extensionDisconnected:(WiimoteExtension*)extension;

@end*/

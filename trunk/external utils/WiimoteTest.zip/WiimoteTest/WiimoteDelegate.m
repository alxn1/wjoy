//
//  WiimoteDelegate.m
//  Wiimote
//
//  Created by alxn1 on 30.07.12.
//  Copyright 2012 alxn1. All rights reserved.
//

#import "WiimoteDelegate.h"

NSString *WiimoteConnectedNotification                  = @"WiimoteConnectedNotification";
NSString *WiimoteDisconnectedNotification               = @"WiimoteDisconnectedNotification";
NSString *WiimoteButtonPresedNotification               = @"WiimoteButtonPresedNotification";
NSString *WiimoteButtonReleasedNotification             = @"WiimoteButtonReleasedNotification";
NSString *WiimoteVibrationStateChangedNotification      = @"WiimoteVibrationStateChangedNotification";
NSString *WiimoteHighlightedLEDMaskChangedNotification  = @"WiimoteHighlightedLEDMaskChangedNotification";
NSString *WiimoteBatteryLevelUpdatedNotification        = @"WiimoteBatteryLevelUpdatedNotification";

NSString *WiimoteButtonKey                              = @"WiimoteButtonKey";
NSString *WiimoteVibrationStateKey                      = @"WiimoteVibrationStateKey";
NSString *WiimoteHighlightedLEDMaskKey                  = @"WiimoteHighlightedLEDMaskKey";
NSString *WiimoteBatteryLevelKey                        = @"WiimoteBatteryLevelKey";
NSString *WiimoteIsBatteryLevelLowKey                   = @"WiimoteIsBatteryLevelLowKey";

@implementation NSObject (WiimoteDelegate_Button)

- (void)wiimote:(Wiimote*)wiimote buttonPressed:(WiimoteButtonType)button
{
}

- (void)wiimote:(Wiimote*)wiimote buttonReleased:(WiimoteButtonType)button
{
}

@end

@implementation NSObject (WiimoteDelegate_Vibration)

- (void)wiimote:(Wiimote*)wiimote vibrationStateChanged:(BOOL)isVibrationEnabled
{
}

@end

@implementation NSObject (WiimoteDelegate_LED)

- (void)wiimote:(Wiimote*)wiimote highlightedLEDMaskChanged:(NSUInteger)mask
{
}

@end

@implementation NSObject (WiimoteDelegate_Battery)

- (void)wiimote:(Wiimote*)wiimote batteryLevelUpdated:(double)batteryLevel isLow:(BOOL)isLow
{
}

@end

@implementation NSObject (WiimoteDelegate)

- (void)wiimoteDisconnected:(Wiimote*)wiimote
{
}

@end

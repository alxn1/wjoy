//
//  WiimoteDeviceReport.h
//  Wiimote
//
//  Created by alxn1 on 29.07.12.
//  Copyright (c) 2012 alxn1. All rights reserved.
//

#import <Foundation/Foundation.h>

@class WiimoteDevice;

@interface WiimoteDeviceReport : NSObject
{
	@private
		NSData					*m_Data;
		NSUInteger               m_Type;
		WiimoteDevice			*m_Device;
}

+ (WiimoteDeviceReport*)parseReportData:(const uint8_t*)data
								 length:(NSUInteger)length
								 device:(WiimoteDevice*)device;

- (NSData*)data;
- (NSUInteger)type; // WiimoteDeviceReportType
- (WiimoteDevice*)device;

@end

//
//  Wiimote+Hardware.m
//  Wiimote
//
//  Created by alxn1 on 30.07.12.
//  Copyright 2012 alxn1. All rights reserved.
//

#import "Wiimote+Hardware.h"
#import "WiimoteProtocol.h"
#import "WiimotePartSet.h"

@implementation Wiimote (Hardware)

- (void)initialize
{
    [self requestUpdateState];
    [self updateReportType];
}

- (void)updateReportType
{
    WiimoteDeviceSetReportTypeParams params;

    params.flags        = 0;
    params.reportType   = [m_Parts bestReportType];

    [m_Device postCommand:WiimoteDeviceCommandTypeSetReportType
                     data:[NSData dataWithBytes:&params length:sizeof(params)]
           vibrationState:[self isVibrationEnabled]];
}

@end

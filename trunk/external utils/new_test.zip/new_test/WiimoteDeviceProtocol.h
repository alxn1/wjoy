//
//  WiimoteDeviceProtocol.h
//  new_test
//
//  Created by alxn1 on 26.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum
{
    WiimoteDevicePacketTypeCommand              = 0xA2,
    WiimoteDevicePacketTypeReport               = 0xA1
} WiimoteDevicePacketType;

typedef enum
{
    WiimoteDeviceCommandTypeSetVibraAndLEDState = 0x11,
    WiimoteDeviceCommandTypeEnableButtonReport  = 0x12
} WiimoteDeviceCommandType;

typedef enum
{
    WiimoteDeviceLEDAndVibraFlagVibraEnabled    = 0x01,
    WiimoteDeviceLEDAndVibraFlagLEDOneEnabled   = 0x10,
    WiimoteDeviceLEDAndVibraFlagLEDTwoEnabled   = 0x20,
    WiimoteDeviceLEDAndVibraFlagLEDThreeEnabled = 0x40,
    WiimoteDeviceLEDAndVibraFlagLEDFourEnabled  = 0x80
} WiimoteDeviceLEDAndVibraFlag;

typedef enum
{
    WiimoteDeviceReportCommandFlagPeriodic      = 0x04
} WiimoteDeviceReportCommandFlag;

typedef enum
{
    WiimoteDeviceReportTypeCoreButtons          = 0x30
} WiimoteDeviceReportType;

typedef enum
{
    WiimoteDeviceReportButtonFlagLeft           = 0x01,
    WiimoteDeviceReportButtonFlagRight          = 0x02,
    WiimoteDeviceReportButtonFlagUp             = 0x08,
    WiimoteDeviceReportButtonFlagDown           = 0x04,
    WiimoteDeviceReportButtonFlagA              = 0x08,
    WiimoteDeviceReportButtonFlagB              = 0x04,
    WiimoteDeviceReportButtonFlagPlus           = 0x10,
    WiimoteDeviceReportButtonFlagMinus          = 0x10,
    WiimoteDeviceReportButtonFlagHome           = 0x80,
    WiimoteDeviceReportButtonFlagOne            = 0x02,
    WiimoteDeviceReportButtonFlagTwo            = 0x01
} WiimoteDeviceReportButtonFlag;

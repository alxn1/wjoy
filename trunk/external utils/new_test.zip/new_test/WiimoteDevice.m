//
//  WiimoteDevice.m
//  new_test
//
//  Created by alxn1 on 25.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "WiimoteDevicePrivate.h"
#import "WiimoteDeviceProtocol.h"
#import "WiimoteInquiry.h"

#import <IOBluetooth/IOBluetooth.h>

NSString *WiimoteDeviceConnectedNotification                    = @"WiimoteDeviceConnectedNotification";
NSString *WiimoteDeviceButtonPresedNotification                 = @"WiimoteDeviceButtonPresedNotification";
NSString *WiimoteDeviceButtonReleasedNotification               = @"WiimoteDeviceButtonReleasedNotification";
NSString *WiimoteDeviceHighlightedLEDMaskChangedNotification    = @"WiimoteDeviceHighlightedLEDMaskChangedNotification";
NSString *WiimoteDeviceVibrationStateChangedNotification        = @"WiimoteDeviceVibrationStateChangedNotification";
NSString *WiimoteDeviceDisconnectedNotification                 = @"WiimoteDeviceDisconnectedNotification";

NSString *WiimoteDeviceButtonKey                                = @"WiimoteDeviceButtonKey";
NSString *WiimoteDeviceHighlightedLEDMaskKey                    = @"WiimoteDeviceHighlightedLEDMaskKey";
NSString *WiimoteDeviceVibrationStateKey                        = @"WiimoteDeviceVibrationStateKey";

@interface WiimoteDevice (PrivatePart)

- (id)initWithBluetoothDevice:(IOBluetoothDevice*)device;

- (IOBluetoothL2CAPChannel*)openChannel:(BluetoothL2CAPPSM)channelID;

- (void)initialize;
- (void)disconnect;

- (void)setButton:(WiimoteButtonType)button pressed:(BOOL)pressed;

- (BOOL)postData:(const void*)data length:(NSUInteger)length;
- (BOOL)postCommand:(WiimoteDeviceCommandType)command
               data:(const void*)data
             length:(NSUInteger)length;

- (BOOL)flushVibraAndLEDState;
- (BOOL)enableButtonReport;

- (BOOL)handleReport:(const unsigned char*)data length:(NSUInteger)length;
- (BOOL)handleCoreButtonReport:(const unsigned char*)data length:(NSUInteger)length;

@end

@interface WiimoteDevice (NotificationPart)

- (void)onConnected;
- (void)onButtonPressed:(WiimoteButtonType)button;
- (void)onButtonReleased:(WiimoteButtonType)button;
- (void)onHighlightedLEDMaskChanged:(NSUInteger)mask;
- (void)onVibrationStateChanged:(BOOL)isVibrationEnabled;
- (void)onDisconnected;

@end

@interface WiimoteDevice (IOBluetoothL2CAPChannelDelegate)

- (void)l2capChannelData:(IOBluetoothL2CAPChannel*)l2capChannel
                    data:(void*)dataPointer
                  length:(size_t)dataLength;

- (void)l2capChannelClosed:(IOBluetoothL2CAPChannel*)l2capChannel;

@end

@implementation WiimoteDevice

+ (BOOL)discovery
{
    return [[WiimoteInquiry sharedInquiry] start];
}

- (id)init
{
    [[super init] release];
    return nil;
}

- (void)dealloc
{
    [self disconnect];
    [super dealloc];
}

- (BOOL)isConnected
{
    return (m_Device != nil);
}

- (NSData*)address
{
    if(m_Device == nil)
        return nil;

    const BluetoothDeviceAddress *address = [m_Device getAddress];
    if(address == NULL)
        return nil;

    return [NSData dataWithBytes:address->data
                          length:sizeof(address->data)];
}

- (NSString*)addressString
{
    return [m_Device getAddressString];
}

- (NSUInteger)highlightedLEDMask
{
    return m_HighlightedLEDMask;
}

- (void)setHighlightedLEDMask:(NSUInteger)mask
{
    if(m_HighlightedLEDMask == mask)
        return;

    m_HighlightedLEDMask = mask;
    if(![self flushVibraAndLEDState])
    {
        [self disconnect];
        return;
    }

    [self onHighlightedLEDMaskChanged:m_HighlightedLEDMask];
}

- (BOOL)isVibrationEnabled
{
    return m_IsVibrationEnabled;
}

- (void)setVibrationEnabled:(BOOL)enabled
{
    if(m_IsVibrationEnabled == enabled)
        return;

    m_IsVibrationEnabled = enabled;
    if(![self flushVibraAndLEDState])
    {
        [self disconnect];
        return;
    }

    [self onVibrationStateChanged:m_IsVibrationEnabled];
}

- (BOOL)isButtonPressed:(WiimoteButtonType)button
{
    return m_ButtonState[button];
}

- (id<WiimoteDeviceDelegate>)delegate
{
    return m_Delegate;
}

- (void)setDelegate:(id<WiimoteDeviceDelegate>)delegate
{
    m_Delegate = delegate;
}

@end

@implementation WiimoteDevice (Private)

+ (WiimoteDevice*)deviceWithBluetoothDevice:(IOBluetoothDevice*)device
{
    return [[[WiimoteDevice alloc] initWithBluetoothDevice:device] autorelease];
}

@end

@implementation WiimoteDevice (PrivatePart)

- (id)initWithBluetoothDevice:(IOBluetoothDevice*)device
{
    self = [super init];
    if(self == nil)
        return nil;

    if(device == nil)
    {
        [self release];
        return nil;
    }

    m_IsInitialiased        = NO;
    m_HighlightedLEDMask    = 0;
    m_IsVibrationEnabled    = NO;

    memset(m_ButtonState, 0, sizeof(m_ButtonState));

    m_Device                = [device retain];
	m_ControlChannel        = [[self openChannel:kBluetoothL2CAPPSMHIDControl] retain];
	m_DataChannel           = [[self openChannel:kBluetoothL2CAPPSMHIDInterrupt] retain];

	if(m_ControlChannel == nil ||
       m_DataChannel    == nil)
    {
		[self release];
        return nil;
    }

    [self initialize];
    if(![self isConnected])
    {
        [self release];
        return nil;
    }

    m_IsInitialiased = YES;
    [self onConnected];

    return self;
}

- (IOBluetoothL2CAPChannel*)openChannel:(BluetoothL2CAPPSM)channelID
{
    IOBluetoothL2CAPChannel *result = nil;

	if([m_Device openL2CAPChannelSync:&result
                              withPSM:channelID
                             delegate:self] != kIOReturnSuccess)
    {
		return nil;
    }

	return result;
}

- (void)initialize
{
    [self setVibrationEnabled:YES];
    [[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.25]];
    [self setVibrationEnabled:NO];

    if(![self enableButtonReport])
        [self disconnect];
}

- (void)disconnect
{
    if(![self isConnected])
        return;

    [m_ControlChannel setDelegate:nil];
	[m_DataChannel setDelegate:nil];

	[m_ControlChannel closeChannel];
	[m_DataChannel closeChannel];
	[m_Device closeConnection];

	[m_ControlChannel release];
	[m_DataChannel release];
	[m_Device release];

	m_ControlChannel     = nil;
	m_DataChannel        = nil;
	m_Device             = nil;

    m_HighlightedLEDMask = 0;
    m_IsVibrationEnabled = NO;

    memset(m_ButtonState, 0, sizeof(m_ButtonState));

    if(m_IsInitialiased)
        [self onDisconnected];
}

- (void)setButton:(WiimoteButtonType)button pressed:(BOOL)pressed
{
    if(m_ButtonState[button] == pressed)
        return;

    m_ButtonState[button] = pressed;

    if(pressed)
        [self onButtonPressed:button];
    else
        [self onButtonReleased:button];
}

- (BOOL)postData:(const void*)data length:(NSUInteger)length
{
    if(m_DataChannel == nil)
        return NO;

    return ([m_DataChannel writeSync:(void*)data length:length] == kIOReturnSuccess);
}

- (BOOL)postCommand:(WiimoteDeviceCommandType)command
               data:(const void*)data
             length:(NSUInteger)length
{
    unsigned char buffer[length + 2];

    buffer[0] = WiimoteDevicePacketTypeCommand;
    buffer[1] = command;
    memcpy(buffer + 2, data, length);

    return [self postData:buffer length:length + 2];
}

- (BOOL)flushVibraAndLEDState
{
    unsigned char data = 0;

    if(m_IsVibrationEnabled)
        data |= WiimoteDeviceLEDAndVibraFlagVibraEnabled;

    if((m_HighlightedLEDMask & WiimoteLEDOne) != 0)
        data |= WiimoteDeviceLEDAndVibraFlagLEDOneEnabled;

    if((m_HighlightedLEDMask & WiimoteLEDTwo) != 0)
        data |= WiimoteDeviceLEDAndVibraFlagLEDTwoEnabled;

    if((m_HighlightedLEDMask & WiimoteLEDThree) != 0)
        data |= WiimoteDeviceLEDAndVibraFlagLEDThreeEnabled;

    if((m_HighlightedLEDMask & WiimoteLEDFour) != 0)
        data |= WiimoteDeviceLEDAndVibraFlagLEDFourEnabled;

    return [self postCommand:WiimoteDeviceCommandTypeSetVibraAndLEDState
                        data:&data
                      length:sizeof(data)];
}

- (BOOL)enableButtonReport
{
    unsigned char data[2];

    data[0] = 0;
    data[1] = WiimoteDeviceReportTypeCoreButtons;

    return [self postCommand:WiimoteDeviceCommandTypeEnableButtonReport
                        data:data
                      length:sizeof(data)];
}

- (BOOL)handleReport:(const unsigned char*)data length:(NSUInteger)length
{
    if(length < 2)
        return NO;

    if(data[0] != WiimoteDevicePacketTypeReport)
        return NO;

    BOOL result = NO;
    switch(data[1])
    {
        case WiimoteDeviceReportTypeCoreButtons:
            result = [self handleCoreButtonReport:data + 2 length:length - 2];
            break;
    }

    return result;
}

- (BOOL)handleCoreButtonReport:(const unsigned char*)data length:(NSUInteger)length
{
    if(length != 2)
        return NO;

    [self setButton:WiimoteButtonTypeLeft pressed:((data[0] & WiimoteDeviceReportButtonFlagLeft) != 0)];
    [self setButton:WiimoteButtonTypeRight pressed:((data[0] & WiimoteDeviceReportButtonFlagRight) != 0)];
    [self setButton:WiimoteButtonTypeUp pressed:((data[0] & WiimoteDeviceReportButtonFlagUp) != 0)];
    [self setButton:WiimoteButtonTypeDown pressed:((data[0] & WiimoteDeviceReportButtonFlagDown) != 0)];
    [self setButton:WiimoteButtonTypePlus pressed:((data[0] & WiimoteDeviceReportButtonFlagPlus) != 0)];

    [self setButton:WiimoteButtonTypeA pressed:((data[1] & WiimoteDeviceReportButtonFlagA) != 0)];
    [self setButton:WiimoteButtonTypeB pressed:((data[1] & WiimoteDeviceReportButtonFlagB) != 0)];
    [self setButton:WiimoteButtonTypeMinus pressed:((data[1] & WiimoteDeviceReportButtonFlagMinus) != 0)];
    [self setButton:WiimoteButtonTypeHome pressed:((data[1] & WiimoteDeviceReportButtonFlagHome) != 0)];
    [self setButton:WiimoteButtonTypeOne pressed:((data[1] & WiimoteDeviceReportButtonFlagOne) != 0)];
    [self setButton:WiimoteButtonTypeTwo pressed:((data[1] & WiimoteDeviceReportButtonFlagTwo) != 0)];

    return YES;
}

@end

@implementation WiimoteDevice (NotificationPart)

- (void)onConnected
{
    [[NSNotificationCenter defaultCenter]
                            postNotificationName:WiimoteDeviceConnectedNotification
                                          object:self];
}

- (void)onButtonPressed:(WiimoteButtonType)button
{
    [m_Delegate wiimoteDevice:self buttonPressed:button];

    NSDictionary *userInfo =
              [NSDictionary dictionaryWithObject:[NSNumber numberWithInteger:button]
                                          forKey:WiimoteDeviceButtonKey];

    [[NSNotificationCenter defaultCenter]
                            postNotificationName:WiimoteDeviceButtonPresedNotification
                                          object:self
                                        userInfo:userInfo];
}

- (void)onButtonReleased:(WiimoteButtonType)button
{
    [m_Delegate wiimoteDevice:self buttonReleased:button];

    NSDictionary *userInfo =
              [NSDictionary dictionaryWithObject:[NSNumber numberWithInteger:button]
                                          forKey:WiimoteDeviceButtonKey];

    [[NSNotificationCenter defaultCenter]
                            postNotificationName:WiimoteDeviceButtonReleasedNotification
                                          object:self
                                        userInfo:userInfo];
}

- (void)onHighlightedLEDMaskChanged:(NSUInteger)mask
{
    [m_Delegate wiimoteDevice:self highlightedLEDMaskChanged:mask];

    NSDictionary *userInfo =
              [NSDictionary dictionaryWithObject:[NSNumber numberWithInteger:mask]
                                          forKey:WiimoteDeviceHighlightedLEDMaskKey];

    [[NSNotificationCenter defaultCenter]
                            postNotificationName:WiimoteDeviceHighlightedLEDMaskChangedNotification
                                          object:self
                                        userInfo:userInfo];
}

- (void)onVibrationStateChanged:(BOOL)isVibrationEnabled
{
    [m_Delegate wiimoteDevice:self vibrationStateChanged:isVibrationEnabled];

    NSDictionary *userInfo =
              [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:isVibrationEnabled]
                                          forKey:WiimoteDeviceVibrationStateKey];

    [[NSNotificationCenter defaultCenter]
                            postNotificationName:WiimoteDeviceVibrationStateChangedNotification
                                          object:self
                                        userInfo:userInfo];
}

- (void)onDisconnected
{
    [m_Delegate wiimoteDeviceDisconnected:self];

    [[NSNotificationCenter defaultCenter]
                            postNotificationName:WiimoteDeviceDisconnectedNotification
                                          object:self];
}

@end

@implementation WiimoteDevice (IOBluetoothL2CAPChannelDelegate)

- (void)l2capChannelData:(IOBluetoothL2CAPChannel*)l2capChannel
                    data:(void*)dataPointer
                  length:(size_t)dataLength
{
    if(![self handleReport:(unsigned char*)dataPointer length:dataLength])
        [self disconnect];
}

- (void)l2capChannelClosed:(IOBluetoothL2CAPChannel*)l2capChannel
{
    [self disconnect];
}

@end

//
//  WDObserver.m
//  WiiTest
//
//  Created by Александр Серков on 13.07.12.
//  Copyright (c) 2012 Александр Серков. All rights reserved.
//

#import "WDObserver.h"
#import <IOBluetooth/IOBluetooth.h>

@implementation WDObserver

+ (WDObserver*)sharedInstance
{
	static WDObserver *result = nil;

	if(result == nil)
		result = [[WDObserver alloc] init];

	return result;
}

- (void)dealloc
{
	[self stop];
	[super dealloc];
}

- (BOOL)isStarted
{
	return (m_Inquiry != nil);
}

- (BOOL)start
{
	if([self isStarted])
		return YES;

	if([IOBluetoothHostController defaultController] == nil)
		return NO;

	m_Inquiry = [[IOBluetoothDeviceInquiry inquiryWithDelegate:self] retain];
	[m_Inquiry setInquiryLength:20];
	[m_Inquiry setSearchCriteria:kBluetoothServiceClassMajorAny majorDeviceClass:0x05 minorDeviceClass:0x01];
	[m_Inquiry setUpdateNewDeviceNames:NO];

	if([m_Inquiry start] != KERN_SUCCESS) {
		[self stop];
		return NO;
	}

	[self willChangeValueForKey:@"started"];
	[self didChangeValueForKey:@"started"];

	return YES;
}

- (BOOL)stop
{
	if(![self isStarted])
		return YES;

	[m_Inquiry stop];
	[m_Inquiry setDelegate:nil];
	[m_Inquiry release];
	m_Inquiry = nil;

	[self willChangeValueForKey:@"started"];
	[self didChangeValueForKey:@"started"];

	return YES;
}

- (id<WDObserverDelegate>)delegate
{
	return m_Delegate;
}

- (void)setDelegate:(id<WDObserverDelegate>)obj
{
	m_Delegate = obj;
}

- (void)deviceInquiryStarted:(IOBluetoothDeviceInquiry*)sender
{
}

- (void)deviceInquiryDeviceFound:(IOBluetoothDeviceInquiry*)sender
						  device:(IOBluetoothDevice*)device
{
	[m_Delegate wdObserver:self deviceFinded:device];
}

- (void)deviceInquiryComplete:(IOBluetoothDeviceInquiry*)sender 
						error:(IOReturn)error
					  aborted:(BOOL)aborted
{	
	[self stop];
}

@end

//
//  WDObserver.h
//  WiiTest
//
//  Created by Александр Серков on 13.07.12.
//  Copyright (c) 2012 Александр Серков. All rights reserved.
//

#import <Foundation/Foundation.h>

@class IOBluetoothDevice;
@class IOBluetoothDeviceInquiry;
@class WDObserver;

@protocol WDObserverDelegate

- (void)wdObserver:(WDObserver*)observer deviceFinded:(IOBluetoothDevice*)device;

@end

@interface WDObserver : NSObject {
@private
	IOBluetoothDeviceInquiry	*m_Inquiry;
	id<WDObserverDelegate>		 m_Delegate;
}

+ (WDObserver*)sharedInstance;

- (BOOL)isStarted;
- (BOOL)start;
- (BOOL)stop;

- (id<WDObserverDelegate>)delegate;
- (void)setDelegate:(id<WDObserverDelegate>)obj;

@end

//
//  WiimoteDevice.h
//  new_test
//
//  Created by alxn1 on 25.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import <Foundation/Foundation.h>

@class IOBluetoothDevice;
@class IOBluetoothL2CAPChannel;

#define WiimoteButtonCount 11

typedef enum
{
    WiimoteButtonTypeLeft       =  0,
    WiimoteButtonTypeRight      =  1,
    WiimoteButtonTypeUp         =  2,
    WiimoteButtonTypeDown       =  3,
    WiimoteButtonTypeA          =  4,
    WiimoteButtonTypeB          =  5,
    WiimoteButtonTypePlus       =  6,
    WiimoteButtonTypeMinus      =  7,
    WiimoteButtonTypeHome       =  8,
    WiimoteButtonTypeOne        =  9,
    WiimoteButtonTypeTwo        = 10
} WiimoteButtonType;

typedef enum
{
    WiimoteLEDOne               =  1,
    WiimoteLEDTwo               =  2,
    WiimoteLEDThree             =  4,
    WiimoteLEDFour              =  8
} WiimoteLED;

FOUNDATION_EXPORT NSString *WiimoteDeviceConnectedNotification;
FOUNDATION_EXPORT NSString *WiimoteDeviceButtonPresedNotification;
FOUNDATION_EXPORT NSString *WiimoteDeviceButtonReleasedNotification;
FOUNDATION_EXPORT NSString *WiimoteDeviceHighlightedLEDMaskChangedNotification;
FOUNDATION_EXPORT NSString *WiimoteDeviceVibrationStateChangedNotification;
FOUNDATION_EXPORT NSString *WiimoteDeviceDisconnectedNotification;

FOUNDATION_EXPORT NSString *WiimoteDeviceButtonKey;
FOUNDATION_EXPORT NSString *WiimoteDeviceHighlightedLEDMaskKey;
FOUNDATION_EXPORT NSString *WiimoteDeviceVibrationStateKey;

@class WiimoteDevice;

@protocol WiimoteDeviceDelegate

- (void)wiimoteDevice:(WiimoteDevice*)device buttonPressed:(WiimoteButtonType)button;
- (void)wiimoteDevice:(WiimoteDevice*)device buttonReleased:(WiimoteButtonType)button;
- (void)wiimoteDevice:(WiimoteDevice*)device highlightedLEDMaskChanged:(NSUInteger)mask;
- (void)wiimoteDevice:(WiimoteDevice*)device vibrationStateChanged:(BOOL)isVibrationEnabled;
- (void)wiimoteDeviceDisconnected:(WiimoteDevice*)device;

@end

@interface WiimoteDevice : NSObject
{
    @private
        IOBluetoothDevice           *m_Device;
        IOBluetoothL2CAPChannel     *m_DataChannel;
        IOBluetoothL2CAPChannel     *m_ControlChannel;

        NSUInteger                   m_HighlightedLEDMask;
        BOOL                         m_IsVibrationEnabled;
        BOOL                         m_IsInitialiased;

        BOOL                         m_ButtonState[WiimoteButtonCount];

        id<WiimoteDeviceDelegate>    m_Delegate;
}

+ (BOOL)discovery;

- (BOOL)isConnected;

- (NSData*)address;
- (NSString*)addressString;

- (NSUInteger)highlightedLEDMask;
- (void)setHighlightedLEDMask:(NSUInteger)mask;

- (BOOL)isVibrationEnabled;
- (void)setVibrationEnabled:(BOOL)enabled;

- (BOOL)isButtonPressed:(WiimoteButtonType)button;

- (id<WiimoteDeviceDelegate>)delegate;
- (void)setDelegate:(id<WiimoteDeviceDelegate>)delegate;

@end

//
//  WiimoteDevicePrivate.h
//  new_test
//
//  Created by alxn1 on 25.07.12.
//  Copyright 2012 Dr. Web. All rights reserved.
//

#import "WiimoteDevice.h"

@interface WiimoteDevice (Private)

+ (WiimoteDevice*)deviceWithBluetoothDevice:(IOBluetoothDevice*)device;

@end

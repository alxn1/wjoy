//
//  WDController.h
//  WiiTest
//
//  Created by Александр Серков on 13.07.12.
//  Copyright (c) 2012 Александр Серков. All rights reserved.
//

#import <Foundation/Foundation.h>

@class IOBluetoothDevice;
@class IOBluetoothL2CAPChannel;

@interface WDController : NSObject {
@private
	IOBluetoothDevice * m_Device;
	IOBluetoothL2CAPChannel *m_InterruptChannel;
	IOBluetoothL2CAPChannel *m_ControlChannel;
}

- (id)initWithDevice:(IOBluetoothDevice*)device;
- (void)dealloc;

- (BOOL)isValid;


@end

//
//  main.m
//  WiiTest
//
//  Created by Александр Серков on 13.07.12.
//  Copyright (c) 2012 Александр Серков. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WDObserver.h"
#import "WDController.h"

@interface Test : NSObject<WDObserverDelegate> {
}

- (void)wdObserver:(WDObserver*)observer deviceFinded:(IOBluetoothDevice*)device;

@end

@implementation Test

- (void)wdObserver:(WDObserver*)observer deviceFinded:(IOBluetoothDevice*)device
{
	WDController *controller = [[WDController alloc] initWithDevice:device];
	if([controller isValid]) {
		NSLog(@"YES!");
	}
	else NSLog(@"NO!");
	[controller release];
}

@end

int main(int argc, const char * argv[])
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	Test *t = [[[Test alloc] init] autorelease];
	[[WDObserver sharedInstance] setDelegate:t];
	[[WDObserver sharedInstance] start];

	[[NSRunLoop currentRunLoop] run];

	[pool drain];
    return 0;
}


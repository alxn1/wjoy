//
//  WDController.m
//  WiiTest
//
//  Created by Александр Серков on 13.07.12.
//  Copyright (c) 2012 Александр Серков. All rights reserved.
//

#import "WDController.h"
#import <IOBluetooth/IOBluetooth.h>

@interface WDController (PrivatePart)

- (IOBluetoothL2CAPChannel*)openChannel:(BluetoothL2CAPPSM)psm;
- (void)closeDevice;

- (void)setLEDEnabled1:(BOOL)enabled1 enabled2:(BOOL)enabled2 enabled3:(BOOL)enabled3 enabled4:(BOOL)enabled4 vibra:(BOOL)vibra;

@end

@implementation WDController

- (id)initWithDevice:(IOBluetoothDevice*)device
{
	self = [super init];
	if(self == nil)
		return nil;

	m_Device = [device retain];
	m_ControlChannel = [[self openChannel:kBluetoothL2CAPPSMHIDControl] retain];
	m_InterruptChannel = [[self openChannel:kBluetoothL2CAPPSMHIDInterrupt] retain];
	if(m_ControlChannel == nil ||
	   m_InterruptChannel == nil) {
		[self closeDevice];
	}

	[self setLEDEnabled1:YES enabled2:NO enabled3:NO enabled4:NO vibra:YES];
	usleep(250000);
	[self setLEDEnabled1:YES enabled2:NO enabled3:NO enabled4:NO vibra:NO];
	return self;
}

- (void)dealloc
{
	[self closeDevice];
	[super dealloc];
}

- (BOOL)isValid
{
	return (m_Device != nil);
}

- (IOBluetoothL2CAPChannel*)openChannel:(BluetoothL2CAPPSM)psm
{
	IOBluetoothL2CAPChannel *channel = nil;
	if([m_Device openL2CAPChannelSync:&channel withPSM:psm delegate:self] != KERN_SUCCESS)
		return nil;

	return channel;
}

- (void)closeDevice
{
	[m_ControlChannel setDelegate:nil];
	[m_InterruptChannel setDelegate:nil];

	[m_ControlChannel closeChannel];
	[m_InterruptChannel closeChannel];
	[m_Device closeConnection];

	[m_ControlChannel release];
	[m_InterruptChannel release];
	[m_Device release];

	m_ControlChannel = nil;
	m_InterruptChannel = nil;
	m_Device = nil;

	NSLog(@"Closed!");
}

- (void)l2capChannelReconfigured:(IOBluetoothL2CAPChannel*)l2capChannel
{
}

- (void)l2capChannelWriteComplete:(IOBluetoothL2CAPChannel*)l2capChannel refcon:(void*)refcon status:(IOReturn)error
{
}

- (void)l2capChannelQueueSpaceAvailable:(IOBluetoothL2CAPChannel*)l2capChannel
{
}

- (void)l2capChannelOpenComplete:(IOBluetoothL2CAPChannel*)l2capChannel status:(IOReturn)error
{
}

- (void)l2capChannelClosed:(IOBluetoothL2CAPChannel*)l2capChannel
{
	[self closeDevice];
} 

- (void)l2capChannelData:(IOBluetoothL2CAPChannel*)l2capChannel data:(void*)dataPointer length:(size_t)dataLength
{
}

- (IOReturn) sendCommand:(const unsigned char *) data length:(size_t) length
{		
	unsigned char buf[40];
	memset(buf, 0, 40);

	buf[0] = 0x52;
	memcpy(buf + 1, data, length);

	if(buf[1] == 0x16) length = 23;
	else length++;

	return [m_ControlChannel writeSync:buf length:length];

	/*IOReturn ret = kIOReturnSuccess;
	
	int i;
	// cam: i think there is no need to do the loop many times in order to see there is an error
	// if there's an error it must be managed right away
	for (i=0; i<10 ; i++) {
		ret = [_cchan writeSync:buf length:length];		
		if (ret != kIOReturnSuccess) {
			NSLogDebug(@"Write Error for command 0x%x:", buf[1], ret);		
			LogIOReturn (ret);
//			[self closeConnection];
			usleep (10000);
		}
		else
			break;
	}

	return ret;*/
}

- (void)setLEDEnabled1:(BOOL)enabled1 enabled2:(BOOL)enabled2 enabled3:(BOOL)enabled3 enabled4:(BOOL)enabled4 vibra:(BOOL)vibra
{
	unsigned char cmd[] = {0x11, 0x00};
	if (vibra)		cmd[1] |= 0x01;
	if (enabled1)	cmd[1] |= 0x10;
	if (enabled2)	cmd[1] |= 0x20;
	if (enabled3)	cmd[1] |= 0x40;
	if (enabled4)	cmd[1] |= 0x80;
	
	[self sendCommand:cmd length:2];
}

@end

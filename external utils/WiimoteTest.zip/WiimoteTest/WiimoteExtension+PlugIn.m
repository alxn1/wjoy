//
//  WiimoteExtension+PlugIn.m
//  Wiimote
//
//  Created by alxn1 on 28.07.12.
//  Copyright 2012 alxn1. All rights reserved.
//

#import "WiimoteExtension+PlugIn.h"
#import "Wiimote.h"
#import "WiimoteExtensionPart.h"

@implementation WiimoteExtension (PlugIn)

+ (void)registerExtensionClass:(Class)cls
{
    [WiimoteExtensionPart registerExtensionClass:cls];
}

+ (void)probeAndInitialize:(id<WiimoteIOManager>)ioManager
                    target:(id)target
                    action:(SEL)action
{
    [target performSelector:action
                 withObject:[NSNumber numberWithBool:YES]
                 afterDelay:0.0];
}

- (id)initWithOwner:(Wiimote*)owner
    eventDispatcher:(WiimoteEventDispatcher*)dispatcher
{
    self = [super init];
    if(self == nil)
        return nil;

    m_Owner             = owner;
    m_EventDispatcher   = dispatcher;

    return self;
}

- (WiimoteEventDispatcher*)eventDispatcher
{
    return m_EventDispatcher;
}

- (void)calibrate:(id<WiimoteIOManager>)ioManager
{
}

- (void)handleReport:(WiimoteDeviceReport*)report
{
}

@end

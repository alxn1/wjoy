//
//  WiimoteIOManager.h
//  Wiimote
//
//  Created by alxn1 on 30.07.12.
//  Copyright 2012 alxn1. All rights reserved.
//

#import "WiimoteProtocol.h"

@protocol WiimoteIOManager

- (BOOL)postCommand:(WiimoteDeviceCommandType)command
			   data:(NSData*)data;

- (BOOL)writeMemory:(NSUInteger)address
			   data:(NSData*)data;

- (BOOL)readMemory:(NSRange)memoryRange
			target:(id)target
			action:(SEL)action;

@end

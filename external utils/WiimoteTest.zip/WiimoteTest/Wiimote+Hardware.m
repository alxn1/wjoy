//
//  Wiimote+Hardware.m
//  Wiimote
//
//  Created by alxn1 on 30.07.12.
//  Copyright 2012 alxn1. All rights reserved.
//

#import "Wiimote+Hardware.h"

@implementation Wiimote (Hardware)

- (void)initialize
{
    [self requestUpdateState];
    [self deviceConfigurationChanged];
}

@end

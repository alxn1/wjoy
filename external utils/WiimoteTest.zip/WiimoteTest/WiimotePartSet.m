//
//  WiimotePartSet.m
//  Wiimote
//
//  Created by alxn1 on 30.07.12.
//  Copyright 2012 alxn1. All rights reserved.
//

#import "WiimotePartSet.h"

@implementation WiimotePartSet

+ (NSMutableArray*)registredPartClasses
{
    static NSMutableArray *result = nil;

    if(result == nil)
        result = [[NSMutableArray alloc] init];

    return result;
}

+ (void)registerPartClass:(Class)cls
{
    if(![[WiimotePartSet registredPartClasses] containsObject:cls])
        [[WiimotePartSet registredPartClasses] addObject:cls];
}

- (id)init
{
    [[super init] release];
    return nil;
}

- (id)initWithOwner:(Wiimote*)owner device:(WiimoteDevice*)device
{
    self = [super init];
    if(self == nil)
        return nil;

    NSArray     *partClasses        = [WiimotePartSet registredPartClasses];
    NSUInteger   countPartClassed   = [partClasses count];

    m_Owner             = owner;
    m_Device            = device;
    m_EventDispatcher   = [[WiimoteEventDispatcher alloc] initWithOwner:owner];
    m_PartDictionary    = [[NSMutableDictionary alloc] initWithCapacity:countPartClassed];
    m_PartArray         = [[NSMutableArray alloc] initWithCapacity:countPartClassed];

    for(NSUInteger i = 0; i < countPartClassed; i++)
    {
        Class        partClass  = [partClasses objectAtIndex:i];
        WiimotePart *part       = [[partClass alloc] initWithOwner:owner
                                                   eventDispatcher:m_EventDispatcher
                                                         ioManager:self];

        [m_PartDictionary setObject:part forKey:partClass];
        [m_PartArray addObject:part];
        [part release];
    }

    [device addReportHandler:self action:@selector(handleReport:) oneShot:NO];
    [device addDisconnectHandler:self action:@selector(disconnect) oneShot:NO];

    [m_EventDispatcher postConnectedNotification];

    return self;
}

- (void)dealloc
{
    [m_EventDispatcher release];
    [m_PartDictionary release];
    [m_PartArray release];
    [super dealloc];
}

- (Wiimote*)owner
{
    return m_Owner;
}

- (WiimoteDevice*)device
{
    return m_Device;
}

- (WiimoteEventDispatcher*)eventDispatcher
{
    return m_EventDispatcher;
}

- (WiimotePart*)partWithClass:(Class)cls
{
    return [m_PartDictionary objectForKey:cls];
}

- (WiimoteDeviceReportType)bestReportType
{
    NSUInteger    countParts  = [m_PartArray count];
    NSMutableSet *reportTypes = [NSMutableSet setWithObjects:
                                    [NSNumber numberWithInteger:WiimoteDeviceReportTypeButtonState],
                                    [NSNumber numberWithInteger:WiimoteDeviceReportTypeButtonAndExtensionState],
                                    nil];

    for(NSUInteger i = 0; i < countParts; i++)
    {
        NSSet *partReports = [[m_PartArray objectAtIndex:i] allowedReportTypeSet];

        if(partReports == nil)
            continue;

        [reportTypes intersectSet:partReports];
    }

    if([reportTypes count] == 0 ||
       [reportTypes containsObject:[NSNumber numberWithInteger:WiimoteDeviceReportTypeButtonState]])
    {
        return WiimoteDeviceReportTypeButtonState;
    }

    return ((WiimoteDeviceReportType)
                    [[reportTypes anyObject] integerValue]);
}

- (void)handleReport:(WiimoteDeviceReport*)report
{
    NSUInteger countParts = [m_PartArray count];

    for(NSUInteger i = 0; i < countParts; i++)
        [[m_PartArray objectAtIndex:i] handleReport:report];
}

- (void)disconnected
{
    NSUInteger countParts = [m_PartArray count];

    for(NSUInteger i = 0; i < countParts; i++)
        [[m_PartArray objectAtIndex:i] disconnected];

    [m_EventDispatcher postDisconnectNotification];
}

- (BOOL)postCommand:(WiimoteDeviceCommandType)command
			   data:(NSData*)data
{
    return [m_Device postCommand:command
                            data:data
                  vibrationState:[m_Owner isVibrationEnabled]];
}

- (BOOL)writeMemory:(NSUInteger)address
			   data:(NSData*)data
{
    return [m_Device writeMemory:address
                            data:data
                  vibrationState:[m_Owner isVibrationEnabled]];
}

- (BOOL)readMemory:(NSRange)memoryRange
			target:(id)target
			action:(SEL)action
{
    return [m_Device readMemory:memoryRange
                 vibrationState:[m_Owner isVibrationEnabled]
                         target:target
                         action:action];
}

@end

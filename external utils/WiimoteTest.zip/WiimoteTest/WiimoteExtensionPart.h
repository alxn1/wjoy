//
//  WiimoteExtensionPart.h
//  Wiimote
//
//  Created by alxn1 on 30.07.12.
//  Copyright 2012 alxn1. All rights reserved.
//

#import "WiimotePart.h"

@class WiimoteExtension;

@interface WiimoteExtensionPart : WiimotePart
{
    @private
        WiimoteExtension *m_Extension;
}

+ (void)registerExtensionClass:(Class)cls;

- (WiimoteExtension*)connectedExtension;

@end

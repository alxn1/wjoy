//
//  WiimoteExtension+PlugIn.h
//  Wiimote
//
//  Created by alxn1 on 28.07.12.
//  Copyright 2012 alxn1. All rights reserved.
//

#import "WiimoteExtension.h"
#import "WiimoteIOManager.h"
#import "WiimoteDeviceReport.h"
#import "WiimoteEventDispatcher.h"

@interface WiimoteExtension (PlugIn)

+ (void)registerExtensionClass:(Class)cls;

+ (void)probeAndInitialize:(id<WiimoteIOManager>)ioManager
                    target:(id)target
                    action:(SEL)action;

- (id)initWithOwner:(Wiimote*)owner
    eventDispatcher:(WiimoteEventDispatcher*)dispatcher;

- (WiimoteEventDispatcher*)eventDispatcher;

- (void)calibrate:(id<WiimoteIOManager>)ioManager;
- (void)handleReport:(WiimoteDeviceReport*)report;

@end

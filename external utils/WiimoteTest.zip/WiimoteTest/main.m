//
//  main.m
//  WiimoteTest
//
//  Created by alxn1 on 29.07.12.
//  Copyright (c) 2012 alxn1. All rights reserved.
//

#import "Wiimote.h"
#import "WiimoteWatchdog.h"

@interface WiimoteWrapper : NSObject
{
    @private
        Wiimote *m_Device;
}

+ (void)run;

@end

@implementation WiimoteWrapper

- (id)initWithDevice:(Wiimote*)device
{
    self = [super init];
    if(self == nil)
        return nil;

    m_Device = [device retain];
    [m_Device setDelegate:self];
    [m_Device setStateChangeNotificationsEnabled:NO];
    [m_Device setHighlightedLEDMask:WiimoteLEDFlagOne];
    [m_Device playConnectEffect];
    NSLog(@"Wrapper created");
	NSLog(@"%@", [Wiimote connectedDevices]);

    return self;
}

- (void)dealloc
{
	NSLog(@"%@", [Wiimote connectedDevices]);
    NSLog(@"Wrapper deleted");
    [m_Device setDelegate:nil];
    [m_Device release];
    [super dealloc];
}

+ (void)newDeviceConnected:(NSNotification*)notification
{
    [[WiimoteWrapper alloc] initWithDevice:[notification object]];
}

+ (void)run
{
    [[NSNotificationCenter defaultCenter]
                                    addObserver:self
                                       selector:@selector(newDeviceConnected:)
                                           name:WiimoteConnectedNotification
                                         object:nil];

    [Wiimote beginDiscovery];
    [[WiimoteWatchdog sharedWatchdog] setEnabled:YES];
    [[NSRunLoop currentRunLoop] run];
}

- (void)wiimote:(Wiimote*)wiimote buttonPressed:(WiimoteButtonType)button
{
    NSLog(@"buttonPressed: %i", button);
}

- (void)wiimote:(Wiimote*)wiimote buttonReleased:(WiimoteButtonType)button
{
    NSLog(@"buttonReleased: %i", button);
}

- (void)wiimote:(Wiimote*)wiimote vibrationStateChanged:(BOOL)isVibrationEnabled
{
    NSLog(@"vibrationStateChanged: %@", ((isVibrationEnabled)?(@"YES"):(@"NO")));
}

- (void)wiimote:(Wiimote*)wiimote highlightedLEDMaskChanged:(NSUInteger)mask
{
    NSLog(@"highlightedLEDMaskChanged: %X", mask);
}

- (void)wiimote:(Wiimote*)wiimote batteryLevelUpdated:(double)batteryLevel isLow:(BOOL)isLow
{
    NSLog(@"batteryLevelUpdated: %.0lf%%, isLow: %@", batteryLevel, ((isLow)?(@"YES"):(@"NO")));
}

- (void)wiimoteDisconnected:(Wiimote*)wiimote
{
    NSLog(@"Disconnected");
    [self autorelease];
}

@end

int main(int argc, const char * argv[])
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [WiimoteWrapper run];
	[pool release];
    return 0;
}

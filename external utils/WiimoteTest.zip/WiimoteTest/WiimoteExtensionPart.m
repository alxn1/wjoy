//
//  WiimoteExtensionPart.m
//  Wiimote
//
//  Created by alxn1 on 30.07.12.
//  Copyright 2012 alxn1. All rights reserved.
//

#import "WiimoteExtensionPart.h"
#import "WiimoteEventDispatcher+Extension.h"
#import "WiimoteExtension+PlugIn.h"

@implementation WiimoteExtensionPart

+ (void)load
{
    [WiimotePart registerPartClass:[WiimoteExtensionPart class]];
}

+ (NSMutableArray*)registredExtensionClasses
{
    static NSMutableArray *result = nil;

    if(result == nil)
        result = [[NSMutableArray alloc] init];

    return result;
}

+ (void)registerExtensionClass:(Class)cls
{
    if(![[WiimoteExtensionPart registredExtensionClasses] containsObject:cls])
        [[WiimoteExtensionPart registredExtensionClasses] addObject:cls];
}

- (id)initWithOwner:(Wiimote*)owner
    eventDispatcher:(WiimoteEventDispatcher*)dispatcher
          ioManager:(id<WiimoteIOManager>)ioManager
{
    self = [super initWithOwner:owner eventDispatcher:dispatcher ioManager:ioManager];
    if(self == nil)
        return nil;

    m_Extension = nil;

    return self;
}

- (WiimoteExtension*)connectedExtension
{
    return [[m_Extension retain] autorelease];
}

- (NSSet*)allowedReportTypeSet
{
    if(m_Extension == nil)
        return nil;

    return [NSSet setWithObject:
                    [NSNumber numberWithInteger:
                                    WiimoteDeviceReportTypeButtonAndExtensionState]];
}

- (void)handleReport:(WiimoteDeviceReport*)report
{
    if([report type] != WiimoteDeviceReportTypeState ||
      [[report data] length] < sizeof(WiimoteDeviceStateReport))
    {
        return;
    }

    const WiimoteDeviceStateReport *state =
                (const WiimoteDeviceStateReport*)[[report data] bytes];

    BOOL isExtensionConnected = ((state->flagsAndLEDState &
                        WiimoteDeviceStateReportFlagExtensionConnected) != 0);

    if(isExtensionConnected)
        NSLog(@"Extension connected");
    else
        NSLog(@"Extension disconnected");
}

- (void)disconnected
{
    [m_Extension release];
    m_Extension = nil;
}

@end
